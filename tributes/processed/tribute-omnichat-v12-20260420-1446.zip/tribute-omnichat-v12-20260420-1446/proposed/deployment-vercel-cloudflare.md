<!-- TRIBUTE-DIFF: additions below — merge into existing deployment-vercel-cloudflare.md -->

<!-- Add this section under "Cloudflare Workers" -->

## Prisma on Cloudflare Workers — REQUIRED pattern

Standard `@prisma/client` emits **CommonJS** (`module.exports`). Cloudflare Workers runtime is **ES modules only**. Deploying a Worker that imports `@prisma/client` directly will fail at runtime with:

```
Uncaught ReferenceError: module is not defined
  at @prisma/client/default.js
```

### Correct pattern

1. **Install the edge client and accelerate extension:**
   ```bash
   npm install @prisma/client @prisma/extension-accelerate
   ```

2. **Import from the edge entry point:**
   ```ts
   // ❌ WRONG — breaks in Workers
   import { PrismaClient } from '@prisma/client';

   // ✅ CORRECT — works in Workers
   import { PrismaClient } from '@prisma/client/edge';
   import { withAccelerate } from '@prisma/extension-accelerate';
   ```

3. **Extend the client with accelerate:**
   ```ts
   const prisma = new PrismaClient({
     datasources: { db: { url: env.DB.connectionString } }
   }).$extends(withAccelerate()) as unknown as PrismaClient;
   ```

4. **Use Hyperdrive for connection pooling to Neon:**
   ```toml
   # wrangler.toml
   [[hyperdrive]]
   binding = "DB"
   id = "{hyperdrive-config-id}"
   ```

5. **Generate Prisma client with `--no-engine` for edge mode:**
   ```bash
   npx prisma generate --schema src/prisma/schema.prisma
   ```

### Health check caveat

`prisma.$queryRaw\`SELECT 1\`` may return false from a healthy DB when using the edge client + Hyperdrive. Prefer:
- A lightweight write-then-read probe, OR
- `prisma.{table}.findFirst({ take: 1 })` against a known-existing table

---

## Vercel Build Recovery — "Unexpected error" pattern

### Symptom
- `vercel --prod` fails with: `Error: Unexpected error. Please try again later. ()`
- No build logs in the Vercel dashboard
- Local `npm run build` passes cleanly

### Diagnosis
- First deploy after linking succeeded; subsequent deploys fail
- Project state in Vercel has entered a broken internal state
- No public API signals this

### Recovery (tested in omnichat-v12)

1. **Delete the Vercel project entirely:**
   ```bash
   vercel rm {project-name} --yes --scope {team}
   ```

2. **Remove local `.vercel/` directory:**
   ```bash
   rm -rf .vercel
   ```

3. **Re-link and deploy fresh:**
   ```bash
   vercel link --yes --scope {team}
   vercel --prod --yes --scope {team} --env KEY=value
   ```

Use `--build-env` to pass variables needed during build (e.g. `NEXT_PUBLIC_*`).

**Caveat:** Environment variables set on the old project are lost — re-add them on the new project, ideally via `vercel env add` before first deploy.
