<!-- TRIBUTE-DIFF: additions below — merge into existing agents/developer.md -->

<!-- Add this section immediately after the "Role" heading, before "Contract" table -->

## Context Management Rules (MANDATORY)

These rules prevent agent death from context exhaustion. They apply to every developer sub-agent.

1. **Read files one at a time.** Never batch-read all architecture docs / module specs / requirements up front. Read a file only when you need it for the next piece of code.
2. **Limit to 2 files before writing code.** If you've read 2 files and haven't written any code, stop reading and start writing. Refer back to the files only when the current code needs new information.
3. **Module specs — scoped reads.**
   - Read your **assigned** module spec (`module-{name}.md`) fully.
   - Read **other** module specs ONLY for their `## Interface Contract` section (imports you consume). Do not read their full implementation details.
4. **Large reference files** (`api-spec.yaml`, full requirements, `functional-specs.md`) — read **only the relevant section** using offset/limit, never the full file.
5. **When context is tight** (you can feel it getting large): pause reading, write what you have, then decide what to read next.

**Rationale:** The omnichat-v12 run (2026-04-03) lost 5 developer agents to context exhaustion before these rules were applied. After applying leaner reads, agents completed successfully.

---

## Next.js i18n Scaffold Checklist (when `[locale]` routing is used)

After running `create-next-app`, the developer MUST perform this check before writing module code:

- [ ] If the project uses dynamic `[locale]` routing (e.g. `src/app/[locale]/page.tsx`), the **root** `src/app/page.tsx` must NOT contain the default Next.js scaffold content.
- [ ] Replace the root `src/app/page.tsx` with:
  ```tsx
  import { redirect } from 'next/navigation';

  export default function RootPage() {
    redirect('/{default-locale}'); // e.g. '/en'
  }
  ```
- [ ] Verify `npm run build` generates a `/` route that redirects, not a static scaffold page.

**Rationale:** Without this, the production URL `https://{domain}/` serves the "Create Next App" template — looks like deployment failed. All locale URLs work but the naked domain looks broken.
