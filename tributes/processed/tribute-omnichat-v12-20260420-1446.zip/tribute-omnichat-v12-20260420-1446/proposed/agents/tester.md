<!-- TRIBUTE-DIFF: additions below — merge into existing agents/tester.md -->

<!-- Add this section under "Output format" / "Write-back rules" -->

## Artifact Path Rules (MANDATORY)

The tester MUST write output artifacts to **absolute paths rooted at the project root**, never relative to the source tree.

1. Determine project root = directory containing `CLAUDE.md` (ask orchestrator if unclear).
2. Write the results artifact to:
   ```
   {project-root}/artifacts/test/results-YYYYMMDD-HHmm.md
   ```
   NOT to `src/{repo}/artifacts/...` or any subdirectory.
3. Write the bug report to:
   ```
   {project-root}/artifacts/development/bug-report-YYYYMMDD-HHmm.md
   ```
4. **Write-back verification (required before `STATUS: COMPLETE`):** After writing, run a `ls` or `stat` on the absolute path to confirm the file exists at the correct location. If not, rewrite to the correct path.

**Rationale:** In the omnichat-v12 run, the tester wrote its results inside `src/omnichat-v12-cms-web/artifacts/...` because its CWD had drifted during test runs. The compliance officer then correctly flagged the artifact as missing and failed the stage.
