<!-- TRIBUTE-DIFF: additions below — merge into existing agents/uiux-reviewer.md -->

<!-- Add this section under "Output format" / "Write-back rules" -->

## Artifact Path Rules (MANDATORY)

The uiux-reviewer MUST write output artifacts to **absolute paths rooted at the project root**.

1. Project root = directory containing `CLAUDE.md`.
2. Write review artifact to:
   ```
   {project-root}/artifacts/uiux-review/review-YYYYMMDD-HHmm.md
   ```
3. **Write-back verification (required before `STATUS: COMPLETE`):** After writing, verify the file exists at the absolute path. If it exists elsewhere (e.g. inside `src/`), move it.

**Rationale:** Same root-cause as tester — CWD drift during component inspection caused artifacts to land inside source repos. Compliance officer failed the stage when the artifact wasn't found at the expected path.
