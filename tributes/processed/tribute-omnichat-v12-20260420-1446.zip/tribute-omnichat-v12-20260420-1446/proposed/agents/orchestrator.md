<!-- TRIBUTE-DIFF: additions below — merge into existing agents/orchestrator.md -->

<!-- Add this section under "Agent Teams" or a new "Recovery Patterns" section -->

## Dead Teammate Recovery (Agent Teams)

When a teammate spawned via `Agent` with `team_name` dies silently (context exhaustion, rate limit, timeout), standard recovery fails:
- `SendMessage` → no response
- `shutdown_request` → no response
- `TeamDelete` → fails with `Cannot cleanup team with N active member(s)`

### Detection

- No file-write activity from the teammate for **> 3 minutes** during an expected active period.
- No response to a direct `SendMessage` within 60 seconds.

### Recovery procedure

1. **Send shutdown_request once** to every teammate (non-blocking).
2. **Wait 60 seconds** for graceful shutdown.
3. If `TeamDelete` still fails — force-remove team and task files:
   ```bash
   rm -rf ~/.claude/teams/{team-name} ~/.claude/tasks/{team-name}
   ```
4. **Respawn as regular sub-agents** (not team members):
   - Use `Agent` tool with the same prompts but *without* the `team_name` parameter.
   - Leaner prompts (see `agents/developer.md` Context Management Rules).
5. Log the dead team in the decision log as an **infrastructure event**, not an agent failure.

### When to prefer regular sub-agents over Team Pipeline

Based on omnichat-v12 findings, **regular sub-agents are more reliable than Agent Teams** for:
- I/O-heavy workloads (repo scaffolding with `create-next-app`, large `npm install`)
- Long-running tasks (> 10 minutes expected duration)
- Workloads that need to read many files

**Team Pipeline works well for:**
- Coordinated reviews (code-reviewer + tester + uiux-reviewer in parallel) — short, read-only, naturally coordinated
- Tasks where mid-flight messaging between agents is actually required

---

**Rationale:** omnichat-v12 run lost an entire Developer Team deadlock. Force-cleanup and respawn as regular sub-agents recovered the pipeline.
