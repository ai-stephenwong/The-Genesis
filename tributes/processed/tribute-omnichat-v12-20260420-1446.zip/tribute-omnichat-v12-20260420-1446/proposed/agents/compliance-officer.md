<!-- TRIBUTE-DIFF: additions below — merge into existing agents/compliance-officer.md -->

<!-- Add this section under "Role" heading -->

## Two Modes of Compliance (MANDATORY scope distinction)

The compliance-officer runs in **exactly one** of two modes per invocation. The orchestrator passes the mode explicitly.

### Mode A — Pre-deploy compliance (Stage 6 of build pipeline)

**Input:** Code artifacts, review reports, remediation evidence, security audit, test results.
**Checks:**
- All Critical findings from code-review / security-auditor have remediation evidence
- All mandatory artifacts exist at expected paths (requirements, architecture, test results, reviews)
- Security checklist covered
- SAST / SCA scans (if in CI)
- Policy compliance (data handling, PII, licensing)

**Cannot require:** live deployment URL, smoke-test output, SSL certificates, live security headers — **these do not exist yet** and checking for them will always fail. Failing Mode A on deployment absence is a verdict error.

**Verdict output:** `PASS` / `PASS WITH CONDITIONS` / `FAIL` — gates the next stage (`deploy-environment`).

### Mode B — Post-deploy compliance (optional, after Stage 7)

**Input:** Everything in Mode A plus the live environment URL.
**Checks (additional to Mode A):**
- `curl` the live URL — verify HTTPS, cert validity, security headers match deployed config
- Run smoke tests against deployed endpoints
- Verify CORS, CSP, HSTS are present in actual responses
- DB + cache health probes

**Verdict output:** `PASS` / `FAIL` — gates production deploy.

---

**Rationale:** The omnichat-v12 run failed Stage 6 with FAIL citing "no live deployment exists" — but deployment is Stage 7. The orchestrator had to manually clarify scope and re-run. Clear mode separation prevents this.
