# Tribute to The Genesis — OmniChat v12

**Submitted by:** omnichat-v12 (child project)
**Date:** 2026-04-20 14:46 HKT
**Pipeline run:** 2026-04-03 10:00 → 2026-04-04 09:40 (Autopilot, Team Pipeline)
**Run outcome:** 7/8 stages complete (production deploy pending), dev environment fully deployed

---

## Summary

This tribute proposes **7 SDLC improvements** identified during a full Autopilot pipeline run of a Next.js 14 + Cloudflare Workers + Vite React project. All improvements are process or agent-prompt refinements derived from real pain points encountered — not speculative changes.

| # | Area | Severity | Root Cause |
|---|------|----------|------------|
| 1 | Developer agent context management | **High** | Agents died mid-stage from context exhaustion reading too many files |
| 2 | Prisma on Cloudflare Workers | **High** | Standard Prisma client uses CommonJS, incompatible with Workers ES modules |
| 3 | Next.js i18n root redirect | **Medium** | Default Next.js scaffold `page.tsx` serves when `[locale]` is the only route pattern |
| 4 | Tester / uiux-reviewer artifact paths | **Medium** | Artifacts written to wrong paths, compliance officer then flagged as missing |
| 5 | Compliance officer pre-deploy scope | **Medium** | R1 verdict failed on "no live deployment" but deploy is the NEXT stage |
| 6 | Agent Teams lifecycle fragility | **Medium** | Dead teammates block team deletion; no force-cleanup mechanism documented |
| 7 | Vercel project fresh-link recovery | **Low** | Builds fail with generic "Unexpected error"; fix is delete + recreate project |

---

## Improvements

### 1. Developer agent — Context management rule

**Problem:** When a developer agent is asked to read the full architecture doc, all module specs, api-spec.yaml, requirements, stack.md, conventions.md, etc. up front, it exhausts context before writing any code. In this run, 3 of 4 initial Phase 1 developer agents died after repo scaffolding with 0 module code produced.

**Root cause:** The developer prompt listed ~12 files to read without guidance on *when* or *how selectively* to read them. Agents defaulted to reading everything sequentially.

**Proposed fix:** Add an explicit **Context Management** section to [agents/developer.md](proposed/agents/developer.md) with three rules:
1. Read files **one at a time**, only when needed for the next piece of code
2. Never read more than 2 files before writing code
3. For module specs: read the assigned module's spec fully; read other modules' specs **only** for their interface contracts (imports section)

**Evidence of impact:** After applying leaner prompts manually during re-run, the same 3 agents completed successfully — dev-web wrote 33 widgets + 20+ pages; dev-api wrote 38 files + 59 endpoints; dev-cms wrote 55 files.

---

### 2. Cloudflare Workers + Prisma — Add to architecture playbook

**Problem:** Worker deploy failed with `Uncaught ReferenceError: module is not defined` from `@prisma/client/default.js`. Standard Prisma client emits CommonJS (`module.exports`) which Cloudflare Workers' ES module runtime rejects.

**Root cause:** `agent_docs/generic/deployment-vercel-cloudflare.md` does not mention this well-known Prisma-on-Workers constraint. Solution-architect correctly chose Neon + Hyperdrive but didn't document the required client variant.

**Proposed fix:** Add a **Prisma on Cloudflare Workers** section to [deployment-vercel-cloudflare.md](proposed/deployment-vercel-cloudflare.md):
- Use `@prisma/client/edge` (not `@prisma/client`)
- Install `@prisma/extension-accelerate` and wrap with `$extends(withAccelerate())`
- Hyperdrive binding provides connection string via `env.DB.connectionString`
- Health check `$queryRaw` may fail even when DB is reachable — prefer a write-then-read smoke test

---

### 3. Next.js i18n — Root redirect pattern

**Problem:** After deploying the Next.js website, the root `/` URL served the default Next.js "Create Next App" scaffold page — not the OmniChat homepage. Only `/en`, `/zh-hk`, etc. worked because the app uses `[locale]` dynamic routing.

**Root cause:** `create-next-app@14` generates a root `src/app/page.tsx` with scaffold content. When the project uses `[locale]` routing, this root file is orphaned but still served for requests to `/`. The developer agent did not remove or replace it.

**Proposed fix:** Add a **Next.js i18n scaffolding** checklist item in [agents/developer.md](proposed/agents/developer.md) under the frontend setup section:
- If the project uses `[locale]` dynamic routing, the root `src/app/page.tsx` must either be **deleted** or contain `redirect('/{default-locale}')` from `next/navigation`
- Add this as a **post-init verification** that the developer agent runs after `create-next-app`

---

### 4. Tester / uiux-reviewer — Artifact path validation

**Problem:** Both the tester and uiux-reviewer agents wrote their output artifacts to paths *inside* the source tree (`src/omnichat-v12-cms-web/artifacts/...`) instead of the project-level `artifacts/` directory. The compliance officer then correctly flagged these as missing and failed the build.

**Root cause:** Agents resolved `artifacts/test/results-*.md` relative to their current working directory (which was inside a repo) rather than project root. No explicit absolute-path instruction in the prompt.

**Proposed fix:** Update [agents/tester.md](proposed/agents/tester.md) and [agents/uiux-reviewer.md](proposed/agents/uiux-reviewer.md) to:
- Require **absolute paths** for artifact outputs, starting at project root
- Add a **Write-Back Verification** step: after writing, run `ls` on the expected absolute path to confirm the file exists there
- Add validation to `post-{stage}.sh` scripts that check `artifacts/{stage}/` exists at project root

---

### 5. Compliance officer — Pre-deploy scope clarification

**Problem:** First compliance run returned FAIL citing "no live deployment exists — smoke test cannot be performed." But the compliance stage is **Stage 6** in the pipeline; deployment is **Stage 7**. This chicken-and-egg verdict required a re-run after clarifying scope.

**Root cause:** [agents/compliance-officer.md](proposed/agents/compliance-officer.md) mixes two concerns — pre-deploy compliance (code, artifacts, policy) vs. post-deploy compliance (smoke tests, live verification). Neither is explicitly distinguished.

**Proposed fix:** Split compliance checks into two explicit modes in [agents/compliance-officer.md](proposed/agents/compliance-officer.md):
- **Mode A: Pre-deploy compliance** (Stage 6) — code artifacts, remediation evidence, SAST/SCA, policy. Cannot require live deployment to exist.
- **Mode B: Post-deploy compliance** (Stage 7 follow-up) — smoke tests against live env, SSL cert, security headers on real host, etc.

The orchestrator passes the mode explicitly when invoking the agent.

---

### 6. Agent Teams — Lifecycle fragility

**Problem:** When team members die silently (context exhaustion, rate limit), `TeamDelete` refuses to clean up because they're still registered as "active". Shutdown requests to dead agents go unanswered, blocking further work.

**Root cause:** The Team Pipeline skill does not document a force-cleanup path. Had to manually `rm -rf ~/.claude/teams/{team-name}` and `~/.claude/tasks/{team-name}` to recover.

**Proposed fix:** Add a **Dead Teammate Recovery** section to the team-pipeline skill (and mirror in [agents/orchestrator.md](proposed/agents/orchestrator.md)):
- If teammate does not respond to shutdown_request within 60s, assume dead
- Force-remove team files: `rm -rf ~/.claude/teams/{name} ~/.claude/tasks/{name}`
- Re-spawn as regular sub-agents (not team members) if Team Pipeline is unstable for that workload
- Document that for I/O-heavy workloads (repo scaffolding, large installs), regular sub-agents are more reliable than teams

---

### 7. Vercel deploy — Fresh-link recovery pattern

**Problem:** After initial link + successful first deploy, subsequent deploys failed with `Error: Unexpected error. Please try again later. ()` — no actionable logs. Local `npm run build` passed. Fix was to delete the Vercel project entirely and re-link from scratch.

**Root cause:** Vercel project state can enter a broken state after a linking issue. No public API signals this; only symptom is opaque errors.

**Proposed fix:** Add a **Vercel Build Recovery** troubleshooting entry to [deployment-vercel-cloudflare.md](proposed/deployment-vercel-cloudflare.md):
- Symptom: `Error: Unexpected error. Please try again later.` with no build logs
- Diagnosis: Local build passes, but remote fails consistently
- Recovery: `vercel rm {project-name} --yes --scope {team}` then `rm -rf .vercel && vercel link --yes --scope {team}` and redeploy

---

## Files in this tribute

All files are in `proposed/` and are drop-in replacements for the corresponding files in The Genesis.

| # | Proposed file | Replaces |
|---|---------------|----------|
| 1 | `proposed/agents/developer.md` | `agent_docs/generic/agents/developer.md` |
| 2 | `proposed/agents/tester.md` | `agent_docs/generic/agents/tester.md` |
| 3 | `proposed/agents/uiux-reviewer.md` | `agent_docs/generic/agents/uiux-reviewer.md` |
| 4 | `proposed/agents/compliance-officer.md` | `agent_docs/generic/agents/compliance-officer.md` |
| 5 | `proposed/agents/orchestrator.md` | `agent_docs/generic/agents/orchestrator.md` |
| 6 | `proposed/deployment-vercel-cloudflare.md` | `agent_docs/generic/deployment-vercel-cloudflare.md` |

> **Note:** Due to scope, only the **diffs/sections** being added are shown in the proposed files. Each proposed file contains a `<!-- TRIBUTE-DIFF -->` marker indicating the addition points. The Genesis maintainer should merge these into the full file bodies.

---

## Pipeline metrics for this run

| Metric | Value |
|--------|-------|
| Total stages completed | 7 / 8 |
| Total process time | ~2h 50m active |
| Wall clock duration | ~24h (rate limits + overnight gaps) |
| Critical findings auto-remediated | 8 code review + 4 security + 5 high security = 17 |
| Source files produced | 252 (3 repos) |
| Tests written | 140 (all passing) |
| Rate limit hits | 2 (recovered each time) |
| Agent deaths | 5 (all recovered via respawn) |

---

## Recommended priority

| # | Priority | Reason |
|---|----------|--------|
| 1 (context mgmt) | **P0** | Caused 5 agent deaths, near-total pipeline failure on first attempt |
| 2 (Prisma+Workers) | **P0** | Pipeline cannot deploy to Workers without this fix; one-line change but critical |
| 3 (Next.js root redirect) | **P1** | Caused "site broken" symptom after successful deploy |
| 4 (artifact paths) | **P1** | Caused false compliance FAIL; wasted a cycle |
| 5 (compliance scope) | **P1** | Caused false compliance FAIL; orchestrator had to intervene |
| 6 (team recovery) | **P2** | Rare but blocks pipeline when it happens |
| 7 (Vercel recovery) | **P2** | Platform issue, but documenting recovery saves hours |

---

## Retrospective-analyst note

No formal retrospective was run — this tribute was produced by the orchestrator directly from pipeline run artifacts. If The Genesis maintainer wants a formal retrospective before processing, trigger with `run retrospective` in omnichat-v12 using the bug report (none was filed — these are *process* improvements, not defects).
