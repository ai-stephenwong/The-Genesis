# Compliance Officer Self-Review — R2 — 2026-03-21

## Round 2 Bug Batch Reference
artifacts/development/bug-report-20260321-0001.md

---

## Implicated Bugs

### BUG-001 — VITE_API_URL wrong env var (classified as TD-009, non-blocking)

**What I classified incorrectly:**

TD-009 was recorded as: "`omnichat-v4-web/src/services/api.ts` reads `VITE_API_URL` but the env var is named `VITE_API_BASE_URL` in `.env.example` and DevOps setup. Fix the key name to `VITE_API_BASE_URL`." It was sourced from CR-016, which the code reviewer had flagged as Major. I carried it forward into the tech debt log with a Major severity label but treated that severity as non-blocking for staging.

The misclassification was not in identifying the issue — I identified it correctly. The misclassification was in the consequences I drew from it. I read it as a variable naming inconsistency (a hygiene issue) rather than as a functional correctness failure in the deployment environment. The production fallback `?? 'https://api.omnichat.ai'` that accompanied the wrong key name should have been the critical signal: it meant that whenever `VITE_API_URL` was unset (which is always, because it does not exist), the service layer would silently route every API call to production. The fallback transformed a naming inconsistency into an environment isolation failure.

**Correct classification:**

This should have been classified as a blocking defect against the staging gate — not tech debt. The precise blocker category would have been an environment correctness violation: staging is only a valid gate if it tests against the staging API. A defect that guarantees all API calls bypass the staging API and hit production renders the staging environment meaningless as a quality gate. The correct disposition was: fix before staging deploy is authorised. No staging PASS verdict is valid while this defect is present.

The source severity from the code reviewer (Major) was also insufficient. The code reviewer framed CR-016 as an env var name mismatch. That framing missed the hardcoded production fallback, which is what made the issue a functional blocker. Had the code reviewer flagged CR-016 as Critical with the fallback as the reason, my re-assessment at the compliance stage would have been easier. However, my obligation as compliance officer is not to simply inherit the upstream severity label — it is to independently assess the consequence of any open finding before authorising a deployment gate. I did not do that for TD-009.

**Why the classification mattered:**

By classifying TD-009 as non-blocking tech debt, I gave the PASS verdict that authorised staging deployment while a defect was present that:

1. Made every API call from the staging website hit `https://api.omnichat.ai` (production).
2. Meant QA testing on staging was testing against production data and production state, not staging.
3. Contaminated the production API with test traffic from staging smoke tests.
4. Meant the staging environment never fulfilled its defined purpose (testing the staging API build before it reaches production).

The staging gate exists precisely to catch regressions before production. A staging environment that silently routes to production does not provide that safety. The PASS verdict I issued actively authorised a deployment that negated the staging gate's purpose. That is a material quality failure, not a deferred maintenance item.

**Classification criteria change:**

Any open finding that touches environment variable names, API base URLs, or deployment configuration must be assessed not just for naming correctness but for runtime consequence. The question to ask is: "If this var is wrong or missing at deploy time, what does the application actually do?" If the answer is "falls back to a hardcoded production URL" or "silently sends traffic to the wrong environment", the finding is a blocking environment correctness defect regardless of how the upstream reviewer framed it.

More specifically, for any future tech debt classification decision involving environment variable bindings, the following additional check is required before a non-blocking designation is accepted:

- Is there a hardcoded fallback? If so, what does it point to? A fallback to a localhost or no-op value is low risk. A fallback to a production URL is a blocker.
- Does the missing or wrong variable affect environment isolation? If yes, it must block the staging gate.
- Is the finding sourced from a cross-service binding check (env var in code vs. declaration in deployment manifest)? If yes, treat it as a potential Critical until the runtime consequence is verified, because silent failures are the defining characteristic of misconfigured bindings.

This criterion applies symmetrically to BUG-004 (CORS_ORIGINS vs ALLOWED_ORIGINS in wrangler.toml) and BUG-005 (CSP connect-src pointing to production in staging config), neither of which were open in my compliance reports but represent the same class of defect: a configuration mismatch with silent runtime failure mode.

---

## PASS Verdict Re-assessment

The PASS verdict issued in `compliance-20260321-0001.md` does not retain full integrity.

Two critical defects were present at pass time that were not detected during the re-check:

**BUG-001 (VITE_API_URL / VITE_API_BASE_URL):** As assessed above, this was an open finding in the tech debt log (TD-009) at the time I issued the PASS. I verified the five blocking issues and correctly confirmed they were fixed. However, my gate check did not include a re-read of the tech debt log to assess whether any non-blocking item's consequence had changed in the context of an imminent staging deploy. Had I done so, TD-009's production fallback should have surfaced as a blocker before the PASS was issued.

**BUG-002 (missing postcss.config.js — site completely unstyled):** This defect was not present in any artifact I reviewed. It was not flagged by the code reviewer, the tester, or the security auditor. The UX reviewer issued a PASS WITH CONDITIONS. None of the upstream artifacts contained evidence that Tailwind CSS was not compiling. My compliance review is artifact-driven: I cross-check findings from upstream agents against standards and track their resolution. I am not designed to independently discover implementation defects not surfaced by any upstream agent. BUG-002 represents a pipeline failure — the UX reviewer should have caught a completely unstyled page, and the tester should have caught that the CSS output was 1.38 kB of raw directives rather than compiled Tailwind. The absence of any such signal in the artifacts I reviewed means BUG-002 is not a compliance review failure in isolation — it is a pipeline failure in which the compliance gate had no basis to act.

However, BUG-001 is different. The evidence for BUG-001 was present in my own tech debt log as TD-009. I had the information. I did not apply the correct consequence analysis before issuing the PASS.

**What this says about the depth of compliance review vs upstream artifact review:**

The compliance officer role is defined as a cross-check of artifacts against standards, not an independent re-audit of source code. This creates a structural dependency: if upstream agents fail to surface a defect in their artifacts, the compliance officer has no artifact-based signal to act on. BUG-002 and BUG-004 and BUG-005 fall into this category.

The one area where the compliance officer does hold a direct, independent obligation is the tech debt log. Every item I classify as non-blocking represents a judgment call I own. For items touching deployment configuration, environment isolation, and cross-service bindings, that judgment call should have included a consequence test: "Does this item prevent the staging gate from functioning correctly?" I applied a severity label (Major) inherited from the code reviewer but did not apply a consequence test at the point of staging gate authorisation. That is the gap.

The "Live Integration Smoke Test" requirement defined in `agent-roles.md` (§ compliance-officer, "Live Integration Smoke Test (required before any pass verdict)") is also directly relevant here. The role definition requires verifying at least one full authentication flow and at least one API-driven page load on a running deployment before issuing a PASS. If that smoke test had been run against the live staging URL, BUG-001 would have been observable: all API calls would have been hitting production rather than the staging API, which would have been detectable from network logs or by checking which environment's data was returned. The smoke test was not documented in `compliance-20260321-0001.md` as having been performed against a live deployment. The re-check report verified fixes in source code only. That is a process gap independent of the TD-009 misclassification.

---

## Overall R1 Compliance Review Quality Assessment

**Strengths:**

- The initial compliance report (`compliance-20260321-0000.md`) correctly issued a FAIL verdict and identified all five blockers with precise, actionable fix descriptions including file paths and line references. BLOCK-004 (canonical URL violation) and BLOCK-005 (coverage below 80%) were genuine catches that required reading across multiple artifacts and applying standards that no upstream agent had explicitly evaluated.
- The tech debt log was thorough: 15 items documented with source finding references and severity levels.
- The standards compliance table was complete and evidence-cited for each row.
- The re-check report (`compliance-20260321-0001.md`) correctly verified the five block fixes with specific evidence (line numbers, test names, assertion text) rather than simply accepting the developer's claim.

**Weaknesses:**

- TD-009 was not consequence-tested before the PASS was issued. The compliance officer had the finding, the source severity, and the description; what was missing was a runtime consequence analysis asking "what happens if this var is wrong at deploy time?"
- The re-check report did not include a live integration smoke test. Fixes were verified in source code; no verification was documented against a running deployment. This is an explicit requirement in the role definition and was not met.
- The tech debt classification process lacked an explicit filter for "does this item affect environment correctness or environment isolation?" That filter would have caught TD-009, and would also catch future equivalent items (CORS origin mismatches, CSP origin mismatches, wrong API base URLs in staging config).
- The compliance report structure did not include a "staging environment correctness" check as a distinct gate item. Environment isolation — confirming that staging points to staging services and not production — is a deployment correctness requirement that sits between the code-correctness gate and the functional testing gate. It was not explicitly checked.

---

## Commitments for R3

1. **Consequence testing for all tech debt items touching deployment configuration.** Before any item referencing an env var name, API base URL, CORS origin, CSP directive, or deployment manifest binding is classified as non-blocking, I will explicitly document the runtime consequence of the item being wrong at deploy time. If the consequence is environment isolation failure or silent routing to a wrong environment, the item is reclassified as blocking.

2. **Staging environment correctness check as an explicit gate item.** The compliance re-check will include a dedicated section: "Staging Environment Isolation Verification." This will verify that every env var referenced in the frontend service layer, the API worker, and the deployment manifests points to the correct staging service and not a production URL. This check applies to: API base URLs, CORS allowed origins, CSP connect-src / img-src / font-src / style-src directives, and any env var with a hardcoded fallback.

3. **Live integration smoke test documented in every PASS verdict.** The re-check report will include a completed Integration Smoke Test Results table as required by `agent-roles.md`. Specifically: full auth flow on the live staging URL, at least one API-driven page load, verification that API calls are reaching the staging API (not production) via network log or response data inspection. No PASS verdict will be issued without this table completed.

4. **Independent re-read of the full tech debt log before issuing any PASS.** At the re-check stage, after confirming all blockers are resolved, I will re-read every tech debt item and apply the consequence test above before issuing the PASS. A PASS verdict should not be issued if any tech debt item, when re-read in the context of the imminent deployment, would have a blocking consequence.

5. **Escalation of hardcoded production fallbacks.** Any instance of a hardcoded production URL or production credential appearing as a fallback value in application code — regardless of how the upstream reviewer classified it — will be treated as a blocking finding by the compliance officer. The staging gate cannot be valid if production URLs are hardcoded as fallbacks.

---

## PILOT STATUS
STATUS: COMPLETE
ARTIFACTS: artifacts/compliance/self-review-20260321-0001.md
