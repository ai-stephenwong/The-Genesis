# UX Reviewer Self-Review — R2 — 2026-03-21

## Round 2 Bug Batch Reference
artifacts/development/bug-report-20260321-0001.md

---

## Implicated Bugs

### BUG-002 — Missing postcss.config.js — site completely unstyled

**What my review missed:**
The R1 UX review passed without noting that the entire public website was completely unstyled. The deployed CSS file was 1.38 kB and contained raw, un-compiled `@tailwind` directives that browsers silently ignore. Every layout, spacing, colour, and typography rule defined via Tailwind classes was a no-op. The review evaluated components as if Tailwind were working — assessing focus ring visibility, colour contrast, touch target sizes (`min-h-[44px]`), and responsive grid layouts — none of which were actually rendering in the deployed build. The review was conducted by reading source code (`.tsx` files) and inferred visual output from class names, rather than verifying the rendered state of the deployed site.

**Responsibility clause missed:**
From `agent_docs/generic/agent-roles.md` — `ux-reviewer` Responsibilities:
> "Check all UI/UX standards are met: accessibility (WCAG 2.1 AA), responsive design, touch targets, focus indicators"

From `agent_docs/generic/uiux-standards.md` — Design System > Tokens:
> "All visual decisions must use design tokens — never hardcode values in components."

Both obligations are meaningless if the build pipeline that compiles those tokens into CSS never runs. The UX review implicitly assumed the styling pipeline was functional without verifying it. A review of visual standards against source code alone, without confirming the compiled output, cannot fulfil the responsibility of checking that UI/UX standards are met in the delivered product.

**What I should have verified:**
1. The compiled CSS output size and content — a correctly compiled Tailwind bundle for a 33-widget, 14-page application should be in the range of 20–60 kB; 1.38 kB is an unambiguous signal of a failed build pipeline.
2. That `postcss.config.js` (or equivalent) existed in the web project root alongside `tailwind.config.ts` — the two files are co-dependent and one without the other produces exactly this failure.
3. That at least one Tailwind utility class (e.g. `bg-brand-primary`, `text-gray-900`) was present in the compiled CSS, confirming the content scan was working.
4. The visual appearance of at least one deployed page — even a screenshot or a browser-rendered preview against the staging URL — before concluding that colour contrast, focus rings, and touch targets met standards.

**Process change:**
Before beginning any UX review on a Tailwind CSS project, perform a build pipeline verification step:
- Confirm `postcss.config.js` (or `postcss.config.cjs`) exists and references `tailwindcss` and `autoprefixer`.
- Confirm the compiled CSS output (`dist/assets/*.css`) is greater than 10 kB for any non-trivial application.
- Confirm at least three brand token class names appear in the compiled CSS output.
- If a staging deployment exists, load the URL and visually confirm styles are present before writing a single finding. A completely unstyled page is a build-pipeline blocker that supersedes all other UX findings and must be logged as Critical before any other review work proceeds.

---

### BUG-003 — Google Fonts never loaded

**What my review missed:**
The R1 UX review assessed typography rendering — including the use of `font-inter`, `font-noto-sans-tc`, `font-noto-sans-sc`, and `font-noto-sans-jp` classes in components serving CJK locales — without verifying that those font families were actually being loaded by the browser. The `index.html` contained only `<link rel="preconnect">` hints to `fonts.googleapis.com` and `fonts.gstatic.com` with no `<link rel="stylesheet">` importing the font CSS. Additionally, the CSP blocked `fonts.googleapis.com` from `style-src` and `fonts.gstatic.com` from `font-src`, meaning even a correctly added font link would have been blocked. The net result: the browser fell back to system fonts for all body and heading text. The review noted that UX-001 flagged the `lang` attribute as a screen reader problem for CJK locales, but it did not flag that CJK users were also receiving no brand typography whatsoever.

**Responsibility clause missed:**
From `agent_docs/generic/uiux-standards.md` — Typography:
> "Maximum 2 typefaces per project (one for headings, one for body)"

And from uiux-standards.md — Design-to-Code Handoff:
> "Spacing, colour, and typography must reference design tokens — not arbitrary values"
> "A design is not ready for development until it has been reviewed and all states are defined"

The font families are first-class brand typography defined in `tailwind.config.ts` under `fontFamily`. Verifying that design tokens for typography are correctly implemented includes verifying the fonts referenced by those tokens are actually delivered to the browser. Checking that `font-inter` appears as a Tailwind class in a component is not the same as checking that Inter is loaded and rendering. The review stopped at the token layer and did not trace through to the delivery layer (`index.html` font loading and CSP policy).

**What I should have verified:**
1. That `index.html` contained a `<link rel="stylesheet">` for each Google Fonts family specified in `tailwind.config.ts` — not merely `<link rel="preconnect">` hints, which are performance hints only and do not load any fonts.
2. That the CSP `style-src` directive in `vercel.json` permitted `https://fonts.googleapis.com` and that `font-src` permitted `https://fonts.gstatic.com` — the font stylesheet and the font binary files are served from different domains and both must be allowed.
3. That the rendered page in a browser actually displayed Inter (or a named web font), not a system fallback — this can be checked via browser DevTools Network tab (looking for `.woff2` requests to `fonts.gstatic.com`) or via the Computed Styles panel confirming the resolved font family.
4. That the CJK font families (Noto Sans TC, SC, JP) loaded for the respective locale routes — not just that the Tailwind class was present in the component.

**Process change:**
Add a typography delivery check as a mandatory step in every UX review:
- Open `index.html` and confirm a `<link rel="stylesheet">` exists for every font family declared in `tailwind.config.ts` `fontFamily`.
- Cross-reference the CSP `style-src` and `font-src` directives against the font provider domains (Google Fonts, Adobe Fonts, self-hosted, etc.) to confirm fonts are not blocked.
- For projects with CJK or non-Latin locales, confirm each locale-specific font family has its own dedicated load mechanism.
- If reviewing against a deployed URL, check the Network tab for `.woff2` responses — their absence when fonts are declared is a definitive failure signal.

---

## Overall R1 UX Review Quality Assessment

**What was strong:**

The R1 review was thorough in the areas it could assess from source code alone. It correctly identified 28 findings across 4 severity levels, including real and impactful issues: the WCAG 2.1 SC 3.1.1 violation for the hardcoded `lang="en"` attribute (UX-001), the systemic i18n bypass across all 33 widgets (UX-002), two broken focus trap implementations in modal dialogs (UX-003, UX-004), the ProfilePage dark-on-light contrast failure (UX-007), the broken ARIA tablist pattern in the carousel (UX-009), and the production-use of emoji as icons across multiple components (UX-011, UX-019, UX-023). The positive findings were also accurate — skip-to-content links, `prefers-reduced-motion` implementation, semantic HTML structure, and MFA flow keyboard handling were all genuinely well-implemented and correctly recognised as such.

**Systematic gaps:**

The R1 review had two structural blind spots that both stem from the same root cause: the review was conducted exclusively by reading source code, without verifying the compiled and delivered output.

The first gap is build pipeline blindness. Confirming that a Tailwind class exists in a `.tsx` file is not the same as confirming that class produces any visual effect in the browser. The R1 review made implicit assertions about colour contrast, focus ring visibility, spacing, and touch target sizes that were factually impossible to verify without a working CSS build. Assessing visual standards requires confirming the build pipeline that produces visual output is functioning.

The second gap is delivery-layer blindness on typography and assets. Confirming that a font family is named in `tailwind.config.ts` is not the same as confirming that font is loaded by the browser. The gap between "token defined" and "asset delivered" requires checking `index.html`, CSP headers, and network responses — none of which are visible in `.tsx` source files.

Both gaps represent the same category of error: the review verified the intent layer (source code) but not the delivery layer (built and deployed output). For a UX review to be valid, it must include at minimum a spot-check of the compiled artefact and, where a deployment is available, a browser-level verification of the rendered output.

---

## Commitments for R3

The following checks will be added as a mandatory pre-review checklist, completed before any findings are written:

1. **CSS build verification** — confirm `postcss.config.js` exists; confirm compiled CSS is greater than 10 kB; confirm at least three brand token class names appear in the compiled output. If any check fails, log a Critical blocker immediately and halt the review until resolved.

2. **Font delivery verification** — for every font family in `tailwind.config.ts` `fontFamily`, confirm a corresponding `<link rel="stylesheet">` exists in `index.html`. Confirm the CSP `style-src` and `font-src` directives permit the font provider's domains. For CJK locales, verify each locale's font family explicitly.

3. **Deployed URL spot-check** — if a staging or dev deployment is available, load at least the homepage and one interior page in a browser before writing findings. Confirm styles are rendering (layout, colour, spacing), fonts are loading (Network tab shows `.woff2` responses), and the page is not displaying a browser-default unstyled document.

4. **CSP cross-reference for external assets** — for any external resource referenced in source (fonts, analytics, video embeds, API endpoints), confirm the CSP in `vercel.json` or equivalent permits each domain in the appropriate directive (`style-src`, `font-src`, `connect-src`, `script-src`, `img-src`). This check overlaps with security-auditor scope but is independently required for UX because a blocked asset is a UX failure regardless of its security classification.

5. **Environment variable completeness check** — confirm that all `import.meta.env.VITE_*` references in `src/services/` have corresponding entries in `.env.example` and that no hardcoded production URL fallback exists. A hardcoded production URL in a staging build is a UX/functional failure (wrong data source) as much as a security concern.

---

## PILOT STATUS

STATUS: COMPLETE
ARTIFACTS: artifacts/ux-review/self-review-20260321-0001.md
