# DevOps Engineer Self-Review — R2 — 2026-03-21

## Round 2 Bug Batch Reference
artifacts/development/bug-report-20260321-0001.md

---

## Implicated Bugs

### BUG-004 — CORS_ORIGINS / ALLOWED_ORIGINS naming mismatch

**What I produced that contributed:**

In `setup-20260321-0000.md` I documented `wrangler.toml` as defining the full Cloudflare Worker configuration, including vars, but I did not publish an explicit variable name registry cross-referencing the names in `wrangler.toml` against the names read by the Worker source code. The staging runbook section 1i (`Cross-Service Variable Alignment Check`) listed `CORS_ORIGINS` as the expected variable name in `wrangler.toml [env.staging.vars]`, consistent with how the variable had been written in `wrangler.toml`. That name originated from the initial setup phase — I authored the `wrangler.toml` that declared the variable as `CORS_ORIGINS`, and I carried that name forward into the runbook alignment table without ever cross-checking it against the name the Worker code actually reads (`ALLOWED_ORIGINS`). The S-08 smoke test I authored tested the CORS preflight at the `workers.dev` subdomain URL where CORS headers may behave differently than when the request carries the Vercel staging origin; this masked the bug during smoke testing.

**Verification step I missed:**

Section 1i should have included an explicit source-code cross-check: for every env var listed in the alignment table, verify the exact name as it appears in the Worker source (i.e. `env.ALLOWED_ORIGINS`, not just as assumed from `wrangler.toml`). The check item read "CORS_ORIGINS in wrangler.toml matches the staging web and CMS hostnames exactly" — this only validates the *value*, not whether the *key name* matches what the code reads. A dedicated step such as: "Confirm each var name in the alignment table against the corresponding `env.<NAME>` reference in source code (grep `src/omnichat-v4-api/src/` for each var name)" was absent.

**How the error propagated:**

The propagation chain was entirely within my own artifacts:

1. `wrangler.toml` was authored with the variable declared as `CORS_ORIGINS` (setup phase — `setup-20260321-0000.md`).
2. No cross-check against Worker source code was performed at setup time — I treated the variable name as my own to define, not as something that had to match an existing code reference.
3. When authoring section 1i of the staging runbook, I populated the alignment table by reading `wrangler.toml` directly. Because `CORS_ORIGINS` was what `wrangler.toml` said, that is what I wrote in the table.
4. The alignment check instruction stated "verify CORS_ORIGINS in wrangler.toml matches the staging hostnames" — a tautology that checked the value was correct but never asked whether the key name itself matched the code.
5. Neither the setup artifact nor the runbook instructed a grep of the Worker source for the actual variable name consumed at runtime.
6. The code-reviewer did not catch the mismatch either (per BUG-004 implication), but that is a separate failure; I should not have relied on the code-reviewer to catch an infrastructure naming inconsistency that I owned.

**Process change:**

1. The cross-service alignment table (section 1i equivalent in future runbooks) must add a column: "Confirmed in source code (grep reference)". For every Worker env var, the grep command and the matched line must be recorded before the check is marked complete.
2. When authoring `wrangler.toml`, variable names must be derived from a grep of existing source code references first — not invented and then later used in code. If source code does not yet exist, a placeholder note must flag that the name must be verified against code before deployment.
3. The S-08 smoke test must be executed with an `Origin` header set to the actual Vercel staging URL (not the workers.dev URL) to ensure CORS headers are validated against the configured allowed origins list.

---

### BUG-005 — CSP connect-src pointing to production API in staging config

**What I produced that contributed:**

I authored `src/omnichat-v4-web/vercel.json` during the setup phase. The `Content-Security-Policy` header I wrote for the public website included `connect-src` and `img-src` directives that referenced `https://api.omnichat.ai` and `https://media.omnichat.ai` — the production domains. These were written as part of the initial security header configuration in the setup session; because a staging-specific `vercel.json` override was not separately defined, the same file was used for both staging Preview deployments and production deployments. The staging runbook section 1i did not include any check of `vercel.json` CSP header values against the staging service URLs. S-10 (my smoke test for security headers) only verified the *presence* of `Strict-Transport-Security` and `X-Frame-Options` — it did not inspect the *contents* of the `Content-Security-Policy` header for environment-correctness.

**Verification step I missed:**

Two distinct steps were absent:

1. **CSP domain alignment check (section 1i):** The staging runbook alignment table should have included a row for the CSP `connect-src` value, requiring it to list `https://api-staging.omnichat.ai` (and any workers.dev fallback URL) rather than the production API domain. Similarly, `img-src` should have been verified against `https://media-staging.omnichat.ai`.

2. **S-10 CSP content inspection:** The smoke test for security headers should have included a step to grep the `Content-Security-Policy` header value for the production domain string — any occurrence of `api.omnichat.ai` (without `-staging`) in a staging deployment response header would immediately flag the misconfiguration.

A specific check such as:
```bash
curl -sf -I "$STAGING_WEB/" 2>&1 | grep "content-security-policy" | grep -v "api.omnichat.ai[^-]"
# Fail if production domain found without -staging suffix
```
would have caught this before smoke tests were declared passed.

**Process change:**

1. The cross-service alignment table must add a row for `CSP connect-src`, listing the expected staging API URL and requiring a grep of `vercel.json` to confirm no production-only domains appear in staging headers.
2. S-10 (or a new S-10b) must be extended to extract the full `Content-Security-Policy` header value and assert: (a) the staging API domain is present, and (b) the production API domain (`api.omnichat.ai` without the `-staging` prefix) is absent.
3. The setup phase must explicitly document that `vercel.json` CSP directives are environment-sensitive and must be reviewed whenever the `vercel.json` is also used for Preview (staging) deployments. If a single `vercel.json` covers both environments, CSP `connect-src` must reference the staging domain for Preview and the production domain for Production — or separate `vercel.json` overrides per environment scope must be used.

---

## Overall R1 DevOps Quality Assessment

**Staging runbook completeness:**
The runbook was thorough in its coverage of provisioning steps, deployment sequencing, and rollback procedure. The 13-item smoke test suite was a genuine strength. However, two structural gaps are now apparent: the pre-deployment checklist was missing a CSP environment-correctness verification, and the smoke tests verified header presence but not header content for environment-sensitive values. A runbook that passes all 13 smoke tests and still ships BUG-004 and BUG-005 reveals that the test design was optimistic — it checked for the expected good-path values without probing for plausible misconfiguration patterns.

**Cross-service alignment check (section 1i) thoroughness:**
Section 1i was the right idea but incompletely executed. It checked that values pointed to staging URLs (for `VITE_API_BASE_URL`, `MEDIA_BASE_URL`) but it did not check: (a) that env var *key names* in `wrangler.toml` matched the names read by source code, and (b) that `vercel.json` CSP directives referenced staging domains. The alignment table had four rows; it should have had at minimum six (adding `ALLOWED_ORIGINS` source-code name check and `CSP connect-src` value check). The instruction for each row also conflated "value is correct" with "name is correct" — these are separate concerns and must be checked independently.

**CSS/build pipeline verification gaps:**
BUG-002 (missing `postcss.config.js` causing zero Tailwind output) and BUG-003 (missing Google Fonts stylesheet) are not primarily devops failures, but the staging runbook did not include any build output sanity check — specifically, no step verified that the compiled CSS file was larger than a baseline threshold, which would have caught the 1.38 kB stub output immediately. A step such as: "verify `dist/assets/*.css` is greater than 10 kB (Tailwind compiled output)" costs nothing to add and would have caught BUG-002 before the staging deployment was declared complete. This is a gap I own in future runbook iterations.

---

## Commitments for R3

1. **Section 1i — alignment table v2:** Expand the cross-service alignment table to include: (a) a "source code name confirmed" column for every Worker env var, with a grep command and matched line; (b) a row for `CSP connect-src` value asserting staging API domain present and production-only domain absent.

2. **S-08 — CORS test hardening:** Rewrite S-08 to use the actual Vercel Preview deployment URL (or `https://staging.omnichat.ai`) as the `Origin` header — not the workers.dev URL — to validate CORS against the real allowed origins list.

3. **S-10 extension — CSP content check:** Extend the S-10 smoke test to inspect the full `Content-Security-Policy` header value and assert no production-only domains appear in a staging deployment response.

4. **Build output size gate:** Add a build verification step to the staging runbook (after `npm run build`, before `vercel deploy`) that asserts the compiled CSS asset is above a minimum size threshold, catching cases where PostCSS/Tailwind is not wired.

5. **wrangler.toml authoring discipline:** In future setup sessions, derive all Worker env var names from existing source code grep results before writing them into `wrangler.toml`. Document the grep command and matched line for each var in the setup artifact.

---

## PILOT STATUS
STATUS: COMPLETE
ARTIFACTS: artifacts/devops/self-review-20260321-0001.md
