# Code-Reviewer Self-Review — R2 — 2026-03-21

## Round 2 Bug Batch Reference
artifacts/development/bug-report-20260321-0001.md

---

## My Responsibility Assessment

### BUG-001 — Wrong env var name (CR-016 revisited)

CR-016 in the R1 review correctly named the failure mode: "all dev/staging environments will hit production API." However, it was classified as Major rather than Critical, and the framing treated it as a naming inconsistency rather than a deployment blocker.

The missing step was tracing the hardcoded fallback `?? 'https://api.omnichat.ai'` to its operational consequence at the deployment boundary: because `VITE_API_URL` was never declared as a Vercel environment variable, the fallback is not a safety net — it is the permanent value in every deployed environment. The distinction between "this might be wrong" (Major) and "this guarantees production traffic from all non-production environments" (Critical/Blocker) was not made. A correct severity analysis would have required simulating the deployed environment: if `VITE_API_URL` is absent from Vercel variables, what does `import.meta.env['VITE_API_URL'] ?? 'https://api.omnichat.ai'` evaluate to? The answer was in the Vercel env vars list in `agent_docs/project/deployment.md` — `VITE_API_BASE_URL` appears there; `VITE_API_URL` does not. That cross-reference was not performed.

**What I would do differently:** Any env var read with a hardcoded production URL as a fallback must be immediately cross-checked against the deployment manifest. If the variable name does not appear in the declared variables list, the finding is Critical — it means the fallback is not a fallback but the permanent value.

---

### BUG-002 — Missing `postcss.config.js`

`postcss.config.js` received zero review coverage in R1. I confirmed that `tailwindcss`, `postcss`, and `autoprefixer` were present in `package.json` devDependencies. I did not verify the build pipeline was wired — i.e., that `postcss.config.js` existed and referenced those packages.

The distinction between "Tailwind is installed" and "Tailwind is compiled at build time" was not treated as a review checkpoint. A Vite project with Tailwind installed but no `postcss.config.js` will silently produce a broken build. This is a well-known configuration requirement and should have been an explicit checklist item: does `postcss.config.js` exist? Does it configure `tailwindcss` and `autoprefixer`?

**What I would do differently:** Add a mandatory build pipeline wiring check: postcss.config.js present and correctly configured whenever Tailwind is in use.

---

### BUG-003 — Google Fonts never loaded

`index.html` contained two `<link rel="preconnect">` tags for `fonts.googleapis.com` and `fonts.gstatic.com`. These are performance hints — they do not load fonts. The actual `<link rel="stylesheet">` tag for the Google Fonts CSS was absent.

In my R1 review I accepted the preconnect tags as evidence that fonts were addressed without checking for the required stylesheet link. The CSP cross-reference — confirming `fonts.googleapis.com` appears in `style-src` and `fonts.gstatic.com` in `font-src` — was also not performed. Both omissions are straightforward checklist failures: review the HTML `<head>` completely, and verify the CSP permits every external resource that the page attempts to load.

**What I would do differently:** Treat `index.html` `<head>` as a mandatory review section: every external resource referenced must have a corresponding CSP directive, and every `preconnect` hint must have a corresponding load mechanism.

---

### BUG-004 — CORS_ORIGINS / ALLOWED_ORIGINS naming mismatch

In the R1 review, `env.ALLOWED_ORIGINS` in the Worker source code was reviewed and its design was noted positively. The binding verification step — confirming that `wrangler.toml` declares the identical variable name — was not performed.

The code was reviewed in isolation. `wrangler.toml` was reviewed in isolation. The cross-referencing step — "does every `env.*` access in the Worker code have a corresponding binding in `wrangler.toml`?" — was not applied systematically. This is a standard integration review step for any serverless deployment and should have been explicit in my checklist.

**What I would do differently:** For every `env.VARIABLE_NAME` access in the Worker, grep `wrangler.toml` for that exact name. Any mismatch is an automatic Critical finding.

---

### BUG-005 — CSP connect-src pointing to production

The `vercel.json` CSP headers were reviewed in R1. Findings SEC-021 and SEC-022 addressed `unsafe-inline` and `X-XSS-Protection`. The `connect-src` and `img-src` domain values were read but not classified as environment-dependent.

A hardcoded `api.omnichat.ai` in a staging config was not identified as incorrect because domain names received less scrutiny than directive keywords. The correct review question — "does this domain match the environment this config file is deployed in?" — was not asked. The environment context (`staging`) was established in `wrangler.toml`; the CSP config in `vercel.json` was not cross-referenced against it.

**What I would do differently:** CSP domain values must be treated as environment-specific configuration. Any hardcoded production domain in a file under a staging config path is an automatic finding.

---

## Pattern Analysis

All 5 bugs share one root cause: **reviewing code intent without verifying deployment integration.**

Each file was reviewed in isolation:
- `api.ts` was reviewed without checking whether `VITE_API_URL` was declared in the deployment manifest
- `package.json` was reviewed without checking whether `postcss.config.js` existed to wire the installed packages
- `index.html` was reviewed without checking whether preconnect hints had corresponding stylesheet loads and CSP coverage
- The Worker code was reviewed without cross-referencing binding names in `wrangler.toml`
- `vercel.json` CSP was reviewed without cross-referencing domain values against the deployment environment

Code review for deployment-integrated systems must trace paths across file boundaries: code → config → deployment manifest → runtime environment. Reviewing files individually and then declaring the integration correct is not sufficient.

---

## Commitments for R3

1. **Add an explicit deployment integration checklist** to the code review process: for every env var access, cross-check against the deployment manifest; for every external resource in HTML, verify CSP coverage; for every Worker binding, verify wrangler.toml name matches.

2. **Treat hardcoded production URLs as automatic Critical findings** regardless of context — in env var fallbacks, CSP directives, or config files scoped to non-production environments.

3. **Verify build pipeline wiring explicitly**: postcss.config.js for Tailwind, Babel/ESBuild config for transforms, any plugin referenced in vite.config.ts must be verified as actually installed and configured.

4. **Apply environment-context review to all config files**: a `vercel.json` in a staging deployment must have all domain values reviewed against the staging environment, not just the directive structure.

5. **Escalate any env var with a production-domain fallback to Critical** regardless of what the variable name suggests — the fallback value determines the real-world consequence if the variable is missing.

---

## Self-Score

Score: 1/5

**Justification:** Five deployment-integration bugs reached staging. BUG-001 was half-caught in R1 (correct root cause identification in CR-016, but wrong severity classification and framing that obscured the deploy-time consequence). BUG-002, BUG-003, BUG-004, and BUG-005 were not raised at all. The R1 review was thorough within the scope of in-code logic, spec compliance, and directive-level CSP analysis — but that scope was insufficient. All 5 R2 bugs are in the deployment integration layer, which received no systematic review coverage. The score reflects that the primary responsibility of a code reviewer — to prevent defective code from progressing — was not met for any of the 5 R2 bugs.
