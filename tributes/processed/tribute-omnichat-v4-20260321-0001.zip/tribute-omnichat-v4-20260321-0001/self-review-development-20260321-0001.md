# Developer Self-Review — R2 — 2026-03-21

## Round 2 Bug Batch Reference
artifacts/development/bug-report-20260321-0001.md

---

## My Responsibility Assessment

### BUG-001 — Wrong env var name (VITE_API_URL vs VITE_API_BASE_URL)

I authored `src/omnichat-v4-web/src/services/api.ts` with `import.meta.env['VITE_API_URL']` and a hardcoded production fallback of `'https://api.omnichat.ai'`. This was a naming error — I typed the wrong variable name and then masked it with a hardcoded production URL so that no local error would surface.

What makes this worse is that the correct variable name, `VITE_API_BASE_URL`, appears in my own R1 artifact (section 5, Run Instructions), in `.env.example`, and in `vite-env.d.ts`. I had the right name documented in three places and still used the wrong name in the one place it mattered — the actual service layer. The hardcoded production fallback then guaranteed the mismatch would cause no error during local development and would only be discovered in a deployed environment, where it silently routed all traffic to production. I built a failure mode that was invisible locally and dangerous in staging.

I should have used `import.meta.env.VITE_API_BASE_URL` with no fallback, so any misconfiguration would produce an immediate, obvious failure rather than silent misdirection.

---

### BUG-002 — Missing postcss.config.js

I installed `tailwindcss`, `postcss`, and `autoprefixer`, created `tailwind.config.ts`, and added `@tailwind` directives to `index.css` — but never created `postcss.config.js`. Without this file, Vite has no instruction to run PostCSS at build time. The `@tailwind` directives passed through to the browser as raw unrecognised at-rules that browsers silently ignore. The compiled CSS was 1.38 kB rather than the expected ~30 kB. The deployed site had zero styles.

The aggravating factor is that my R1 artifact (section 2, Config file registry for omnichat-v4-web) explicitly listed `postcss.config.js` as a delivered file. It was not delivered. I signed off a completion artifact that described a file that was never written. Whether this was a memory error or an intent I never executed, the result is the same: my artifact gave every downstream agent — code-reviewer, tester, UX reviewer, devops-engineer — a false picture of the project state. This is a documentation integrity failure layered on top of the implementation failure.

Wiring Tailwind through PostCSS is a mandatory, well-known step for any Vite + Tailwind setup. It is not an edge case. I missed it and then reported I had done it.

---

### BUG-003 — Google Fonts never loaded

I added `<link rel="preconnect">` hints for `fonts.googleapis.com` and `fonts.gstatic.com` in `index.html` but never added the `<link rel="stylesheet">` that actually fetches the font CSS. Preconnect hints only warm the TCP/TLS connection — they do not load anything. Without the stylesheet link, the browser opens a connection it never uses and the fonts are never downloaded. Inter, Noto Sans TC, Noto Sans SC, and Noto Sans JP — all declared as first-class brand typography in `tailwind.config.ts` — were never visible on any page.

Compounding this, the CSP in `vercel.json` blocked `fonts.googleapis.com` under `style-src` and `fonts.gstatic.com` under `font-src`. Even if the stylesheet link had existed, the CSP would have blocked the fonts from loading. I independently created two failure modes for the same feature: the HTML was missing the load instruction, and the CSP would have rejected the load even if the instruction had been present.

The root cause is that I implemented the preconnect hints — the performance optimisation step — and treated that as sufficient, without tracing the complete font loading pipeline: preconnect, stylesheet link, CSP allowlist for stylesheet domain, CSP allowlist for font file domain. I verified none of these end-to-end.

---

### BUG-004 — CORS_ORIGINS / ALLOWED_ORIGINS naming mismatch in wrangler.toml

In the Cloudflare Worker source code I read the environment variable as `env.ALLOWED_ORIGINS`. In `wrangler.toml` I declared the binding as `CORS_ORIGINS`. These are different names. At runtime the Worker would have received `undefined` for `ALLOWED_ORIGINS`, causing all CORS preflight requests to fail silently or be rejected.

This is a straightforward transcription error. I defined a variable name in the application code and used a different name in the deployment manifest that was written in the same build session. I did not cross-check the two files against each other before completing the task.

An additional inconsistency: my R1 artifact's run instructions (section 5) document the local env var as `CORS_ALLOWED_ORIGINS` — a third variant of the name, distinct from both `CORS_ORIGINS` in `wrangler.toml` and `ALLOWED_ORIGINS` in the code. This means I used three different names for the same variable across three artefacts written in the same session. I was not working from a single, established name; I was improvising the name each time I wrote it.

---

### BUG-005 — CSP connect-src pointing to production API in staging config

In `src/omnichat-v4-web/vercel.json` I hardcoded `https://api.omnichat.ai` and `https://media.omnichat.ai` in the CSP `connect-src` and `img-src` directives. These are production domain names. In the staging deployment, any browser enforcing CSP would block requests to the actual staging API URL (the `*.workers.dev` domain), which was not listed.

The root cause is that I wrote the CSP headers once with production values and did not adapt them for the staging environment. CSP headers in `vercel.json` are part of the deployment configuration and must be environment-aware. I treated them as static application-level configuration rather than as environment-specific deployment config that must agree with the other environment-specific values (API base URL, CORS origins, media CDN URL) across all relevant files.

This bug is also the mirror image of BUG-001: BUG-001 had `api.ts` pointing to the wrong API domain; BUG-005 had the CSP allowing the wrong API domain. The two bugs together show I did not maintain a single, coherent view of "which API URL does this environment use" across all the files that needed to agree on that answer.

---

## Pattern Analysis

Three systemic patterns account for all five bugs.

**Pattern 1 — No cross-file consistency verification before sign-off.**

BUG-001, BUG-004, and BUG-005 are all naming or domain mismatches between two or more files that were required to agree. `VITE_API_URL` vs `VITE_API_BASE_URL` across `api.ts`, `.env.example`, and `vite-env.d.ts`. `CORS_ORIGINS` vs `ALLOWED_ORIGINS` vs `CORS_ALLOWED_ORIGINS` across `wrangler.toml`, Worker source, and the run instructions. Production API domain in CSP `connect-src` vs staging API domain used at runtime. In every case I wrote a value in one file and a different value in another file that needed to match it, and I never read them side-by-side to verify. A single cross-file audit before submitting each artefact would have caught all three.

**Pattern 2 — No build output inspection.**

BUG-002 and BUG-003 are both failures that would have been caught within seconds of loading the built site. The compiled CSS was 1.38 kB — a number so obviously wrong for a Tailwind build that it is impossible to miss if you look at it. The fonts would have visibly failed to load in any browser with DevTools open. I produced a completion artefact without running the build and inspecting its output. There was no moment of "does this actually work" before I declared it done.

**Pattern 3 — Artefact accuracy not verified against actual file state.**

My R1 completion artefact listed `postcss.config.js` as a delivered file. It was not delivered. I wrote the artefact from memory or intent rather than from verified file state. Every downstream agent who read my R1 artefact had an inaccurate picture of what had been built. This is not a minor record-keeping error — it actively undermined the code-reviewer's ability to assess the build, the tester's ability to know what to test, and the devops-engineer's ability to know what configuration existed. A completion artefact that does not accurately reflect reality is worse than no artefact, because it provides false confidence.

There is also a secondary pattern worth naming: **silent failure modes that defer discovery to deployed environments.** The production URL fallback in `api.ts` (BUG-001) prevented the mismatch from surfacing locally. The CSP headers (BUG-005) are not enforced in local dev. The CORS mismatch (BUG-004) would not appear until a cross-origin request was made against the live deployment. In each case I did not design the configuration to fail loudly on misconfiguration; I wrote configurations that would behave differently in dev vs deployed environments in ways that deferred problems rather than surfacing them.

---

## Commitments for R3

1. **Mandatory env var name audit before completing any task.** For every environment variable referenced in application code (`import.meta.env.VITE_*` in frontend, `env.VAR` in Workers, `process.env.VAR` in Node), I will verify the exact name appears consistently in: the source file, `.env.example`, the TypeScript declaration file (`vite-env.d.ts` or `types/env.ts`), the deployment manifest (`wrangler.toml` or `vercel.json` env blocks), and the run instructions in the development notes artefact. All five must match exactly.

2. **Build output inspection is mandatory before sign-off.** I will run `npm run build` for each frontend repository and verify: (a) CSS output size is greater than 10 kB for any Tailwind project; (b) `dist/index.html` contains the expected `<link rel="stylesheet">` for any fonts declared in `tailwind.config.ts` `fontFamily`; (c) no build warnings about unresolved configuration.

3. **Completion artefacts must be generated from verified file state, not from memory.** Before writing any file registry in a development notes artefact, I will confirm each listed file exists on disk. I will not list a file as delivered unless it was written in that session and I can confirm its existence. If a file I intended to create was not created, it must be listed as a known gap, not as a delivered file.

4. **No hardcoded fallbacks that mask misconfiguration.** Where an environment variable is required for correct operation, the application must throw or produce an obvious startup failure if the variable is absent or empty. A hardcoded production URL as a fallback is not a safety net — it is a deferred production incident.

5. **CSP headers reviewed as environment-scoped deployment config, not static code.** For every deployment environment, I will verify that the domains listed in `connect-src`, `img-src`, `font-src`, and `style-src` exactly match the services deployed to that environment. The CSP domain set for staging must list staging service URLs; the CSP domain set for production must list production service URLs. These must be checked alongside the API base URL and CORS origins list as a single coherent set.

6. **Font loading chain verified end-to-end.** For any project using external web fonts: I will trace the complete chain — `fontFamily` declaration in Tailwind config, `<link rel="preconnect">` hint in HTML, `<link rel="stylesheet">` in HTML, CSP `style-src` allowlist for the stylesheet domain, CSP `font-src` allowlist for the font file domain — and confirm every step is present before sign-off.

---

## Self-Score

Score: 1/5

Justification: Five bugs across three files, all introduced in a single build session, all my direct responsibility. Three of them (BUG-001, BUG-004, BUG-005) are simple naming or value mismatches between files that existed simultaneously and should have been cross-checked. One (BUG-002) is a missing foundational configuration file that produced a completely unstyled site and that I incorrectly reported as delivered in my own artefact. One (BUG-003) is an incomplete implementation where I put in place the optimisation step for a feature (preconnect hints) without delivering the feature itself (font stylesheet), and simultaneously wrote a CSP that would have blocked the feature even if I had delivered it.

None of these bugs required complex investigation to discover. They were all visible on first load of the deployed site in a browser with DevTools open. The R1 artefact contained at least one material inaccuracy — listing a file as delivered that was never created — which degraded the reliability of my output as a source of truth for every other agent in the pipeline. A score above 1 is not justifiable.
