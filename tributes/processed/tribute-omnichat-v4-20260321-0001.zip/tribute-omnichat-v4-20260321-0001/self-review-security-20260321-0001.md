# Security Auditor Self-Review — R2 — 2026-03-21

## Round 2 Bug Batch Reference
artifacts/development/bug-report-20260321-0001.md

---

## Implicated Bugs

### BUG-005 — CSP `connect-src` pointed to production API in staging config

**File implicated:** `src/omnichat-v4-web/vercel.json`
**Symptom:** `connect-src` listed `https://api.omnichat.ai` (production) and `https://media.omnichat.ai` (production media CDN) — not the staging equivalents. Any CSP-enforcing browser would block XHR/fetch calls to the staging workers.dev URL, breaking all API connectivity in a staging-deployed frontend.

---

**What my audit missed:**

The R1 audit read `vercel.json` and produced two findings from it:

- **SEC-021** — `'unsafe-inline'` in `script-src` and `style-src` weakens XSS protection.
- **SEC-022** — Deprecated `X-XSS-Protection` header present.

Both findings examined *the structure and values of CSP directives for security weakness*. Neither examined whether *the domain values inside those directives were environment-appropriate*. Specifically, the `connect-src`, `img-src`, and related directives referenced production hostnames (`https://api.omnichat.ai`, `https://media.omnichat.ai`). These were read as present and syntactically valid. The audit did not ask the question: "Do these URLs point to the correct environment for the current deployment target?"

Additionally, in finding SEC-011, the audit explicitly stated: "The Vercel frontends (`vercel.json`) do correctly set CSP headers — this finding applies only to the Cloudflare Worker API responses." This was accurate in a narrow sense — the CSP headers were structurally present and correctly formatted — but the sentence implicitly cleared the `vercel.json` CSP from further scrutiny. That clearance was premature. Structural presence of a CSP is not the same as correctness of its content across deployment environments.

---

**Checklist item missed:**

From `security-checklist.md`, section "Secure Development & Change Management" (ISO 27001: 8.31):

> "Dev, staging, and production environments strictly separated"

And from the OWASP Top 10 checklist item in the same file:

> "A05 Security Misconfiguration — debug mode off, default credentials changed"

The broader A05 definition in OWASP Top 10 2021 explicitly includes: *misconfigured security controls, using the wrong configuration for a specific environment, or having production credentials/endpoints wired into a non-production environment.* A `connect-src` directive pointing to the production API in a staging config is a textbook A05 misconfiguration: a security control (CSP) is deployed with settings appropriate for a different environment, causing it to enforce incorrect restrictions.

The checklist item that should have been applied — and was not — is the environment separation check under "Secure Development & Change Management" combined with A05 verification. The security checklist does not contain an explicit line item for "verify CSP domain values are environment-specific." That is a gap in the checklist itself (see Process Changes below), but the A05 and environment separation items were sufficient triggers for this check to have been performed.

---

**What I should have verified:**

When reviewing `vercel.json` CSP headers, I should have:

1. **Read every domain value in every CSP directive** — not only checked which directives were present and whether they contained known-unsafe keywords (`'unsafe-inline'`, `'unsafe-eval'`, wildcard `*`). For each domain in `connect-src`, `img-src`, `font-src`, `frame-src`, and `script-src`, I should have asked: "Is this the correct domain for the environment this config file controls?"

2. **Identified that `vercel.json` is a single static file deployed to all Vercel environments** — there is no native `vercel.json` per-environment equivalent for headers. The staging override mechanism (if any) must be explicit. Absence of an explicit per-environment CSP override means the same `connect-src` value applies in both staging and production.

3. **Cross-checked CSP `connect-src` against the API base URL for each environment** — the deployment runbook (`agent_docs/project/deployment.md`) and `wrangler.toml` staging config both document the staging API URL (`https://omnichat-v4-api-staging.stephen-api.workers.dev`). A cross-check between `connect-src` values and the documented staging API URL would have immediately surfaced the mismatch.

4. **Flagged the absence of a staging-specific CSP override mechanism** as a configuration risk, separate from whether the current values happened to be correct.

The correct scope of CSP review is: (a) structural completeness, (b) absence of unsafe keywords, AND (c) domain value correctness per deployment environment. My R1 audit covered (a) and (b) but not (c).

---

**Process change:**

1. **Add explicit CSP domain verification step to the security audit methodology.** For every `connect-src`, `img-src`, `font-src`, `frame-src`, and `script-src` domain listed in any frontend deployment config (`vercel.json`, `_headers`, `next.config.js`, etc.), cross-check each domain against the API base URL and CDN origin documented in the deployment runbook for the target environment. Flag any mismatch as A05 HIGH.

2. **Extend the A05 (Security Misconfiguration) check to explicitly cover environment-specific config values**, not only structural headers presence. The question template should be: "If this config file is deployed to staging, do its values point to staging services? If deployed to production, do they point to production services?"

3. **Request or confirm that the project has a per-environment CSP override strategy** when vercel.json is used. Where no such strategy exists, flag the absence as a misconfiguration risk — the same file governs multiple environments, which means any environment-specific value is a latent misconfiguration.

4. **Raise a gap report to The Genesis framework** to add an explicit checklist item to `security-checklist.md`:
   - Under "CORS & Headers": `[ ] CSP directive domain values verified against the documented API base URL and CDN origin for the target deployment environment — production values in staging config (or vice versa) are A05 FAIL`

---

## R1 Score Re-assessment

**Was 5/5 justified?**

Within the scope of what the R1 audit actually checked — finding all five BLOCKER-severity vulnerabilities, producing correct OWASP categorisations, reading infrastructure configuration files (`wrangler.toml`) beyond just `src/`, and covering 26 discrete findings across the full severity stack — the 5/5 score was defensible. The retrospecive-analyst's rationale was: "All blockers found. Infrastructure-level vulnerability identified before any deployment." That rationale holds on the facts as they were known at the time.

However, BUG-005 reveals that the 5/5 score was earned within a scope that had an undeclared blind spot. The audit correctly found CSP issues in `vercel.json` (two findings: SEC-021 and SEC-022), which gave a reasonable basis to consider CSP coverage complete. It was not complete. The findings addressed *CSP header quality* (unsafe-inline, deprecated X-XSS-Protection) but not *CSP header correctness for deployment context*.

In retrospect, 5/5 should be read as "5/5 within the audit methodology applied." The methodology itself had a gap. The score is not dishonest, but it is incomplete without this qualification.

**What BUG-005 reveals about audit scope gaps:**

The gap is conceptual, not attentional. The R1 audit framed CSP review as a security-weakness analysis: "Does this CSP weaken XSS protection?" It did not frame it as a configuration-correctness analysis: "Does this CSP match the environment it is deployed to?" These are two distinct questions. A security audit that focuses exclusively on the first question will miss the second class of misconfiguration.

This is a general class of blind spot: **environment-context mismatches in static configuration files**. Other instances of this pattern that the R1 audit also did not flag (but which were caught as separate bugs by devops-engineer and code-reviewer scope):

- BUG-001: `api.ts` hardcoded `'https://api.omnichat.ai'` as the API base URL fallback (an environment-context mismatch in application code, caught by the code-reviewer, not the security-auditor).
- BUG-004: `wrangler.toml` `CORS_ORIGINS` vs `ALLOWED_ORIGINS` naming mismatch (a binding-name mismatch, caught independently, attributed to developer and code-reviewer, not security-auditor).

BUG-001 in particular is security-adjacent: hardcoded production API URLs in application code used during staging testing effectively connect staging sessions to production data. The security auditor read `wrangler.toml` for the KV binding mismatch (SEC-001) and found it, demonstrating willingness to read infrastructure config. The `vercel.json` `connect-src` domain values were in scope by the same reasoning but were not verified for environment appropriateness.

**Revised assessment of R1 audit quality:**

The R1 score of 5/5 should be revised to 4/5 in light of BUG-005. The audit was high-quality — 26 findings, all five blockers identified, correct OWASP mapping, infrastructure config reading — but it had one identifiable blind spot that resulted in a real staging breakage escaping to the bug batch. A 4/5 reflects: strong performance with one category gap now identified and corrected.

---

## Overall R1 Audit Quality Assessment

**Strengths demonstrated in R1:**

- All five BLOCKER findings identified with precise file and line evidence.
- Infrastructure-level misconfiguration (KV binding) found by reading beyond `src/` — required initiative not specified in the default audit scope.
- SEC-005 (audit log cursor direction) demonstrated cross-layer reasoning: a logical programming error correctly framed as a security monitoring failure (ISO 27001 §8.15 forensic evidence gap), not merely a bug.
- SEC-016 (CMS audit API calling wrong path `/v1/audit-log` vs `/v1/audit`) found by cross-referencing frontend service layer against backend route registration — a compliance-officer class of check performed proactively.
- Positive findings section documented 10 genuine security strengths, providing balanced evidence that the codebase had meaningful security investment.
- OWASP Top 10 and ISO 27001 control mapping tables produced and populated correctly.

**Weaknesses identified in R1 (now known):**

- CSP review was scoped to *header quality* (unsafe keywords, deprecated headers) but not *header correctness* (domain values matching deployment environment). BUG-005 is a direct result.
- The audit did not verify that BUG-001's hardcoded production API URL fallback in `api.ts` represented a security concern (environment isolation failure). This was in-scope for A05 and the "Dev, staging, and production environments strictly separated" checklist item. Attribution for BUG-001 went to developer and code-reviewer; the security-auditor was not implicated — but an A05-aware review of `api.ts` should have caught it.
- No explicit verification that CSP domains in `vercel.json` aligned with documented environment URLs in the deployment runbook — this cross-reference was not performed.

**Net assessment:**

The R1 audit was high quality but contained a methodological gap in CSP review scope. The gap is specific and correctable. It did not affect the primary mission (finding blockers before production) since BUG-005 was rated Major (not Critical/Blocker), and the staging environment is the furthest live environment at this project stage. The gap has no production security consequence at the time of discovery, but it demonstrates that the audit's A05 coverage was partial.

---

## Commitments for R3

1. **CSP domain verification:** For every CSP header in every frontend deployment manifest (`vercel.json`, `_headers`, platform equivalents), verify each domain value in `connect-src`, `img-src`, `font-src`, `frame-src`, and `script-src` against the deployment runbook's documented API base URL and CDN origin for the target environment. Flag any mismatch as A05 HIGH minimum.

2. **Environment-context config audit:** Extend the A05 check to cover all static configuration values that reference external services (API URLs, CDN origins, OAuth redirect URIs, analytics endpoint overrides). For each: confirm the value matches the environment the config governs.

3. **Per-environment override strategy review:** When a single config file (`vercel.json`) is used across multiple environments without a native override mechanism, flag the absence of an override strategy as a configuration risk and confirm that all environment-specific values have been explicitly reviewed for each target environment.

4. **Application-layer URL hardcoding:** Review all frontend service layer files (`src/services/*.ts`) for hardcoded domain strings. Any hardcoded production domain in a file that runs in staging is an A05 misconfiguration regardless of whether it is also a functional bug.

5. **Raise checklist gap to The Genesis:** Submit a retrospective improvement proposal to add an explicit CSP domain verification item to `agent_docs/generic/security-checklist.md` under "CORS & Headers" and to `agent_docs/generic/uiux-standards.md` if relevant to the frontend deployment verification checklist.

6. **Re-score honestly:** Accept the revised R1 score of 4/5. The 5/5 score, while earned within the methodology applied, did not account for the CSP environment-correctness blind spot. Accurate self-assessment is a prerequisite for improving the audit methodology.

---

## PILOT STATUS
STATUS: COMPLETE
ARTIFACTS: artifacts/security/self-review-20260321-0001.md
