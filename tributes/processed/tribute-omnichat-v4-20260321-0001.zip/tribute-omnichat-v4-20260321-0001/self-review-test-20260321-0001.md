# Tester Self-Review — R2 — 2026-03-21

## Round 2 Bug Batch Reference
artifacts/development/bug-report-20260321-0001.md

---

## My Responsibility Assessment

### BUG-001 — Wrong env var name (API calls hitting production)

**What test should have caught this:**
A service-layer unit test or integration contract test for `api.ts` should have asserted that `VITE_API_BASE_URL` (and only that variable) is read when constructing the API base URL, and that no hardcoded production domain (`api.omnichat.ai`) appears as a fallback. Specifically:

- A test that mounts the service with `VITE_API_BASE_URL` set to a test value and asserts all outgoing requests use that value.
- A test that asserts the service throws or fails explicitly when `VITE_API_BASE_URL` is absent — rather than silently falling back to a production URL.
- A contract test or snapshot test that asserts the configured base URL matches the expected staging domain in a staging environment context.

**What was missing from the test suite:**
There were zero tests for `src/omnichat-v4-web/src/services/`. The services layer was entirely untested. The R1 results report coverage of five widget components and two hooks, with no mention of `api.ts` or any service file. I did not include service-layer env var configuration in my test scope.

**Why the tests did not catch this:**
I scoped my frontend testing exclusively to UI rendering behaviour (widgets, hooks, i18n) and treated the services layer as out of scope for R1. I made no attempt to verify that the runtime configuration the app read at build time matched the intended environment. I also did not include any test that would have detected a hardcoded production URL as a fallback — this is a configuration correctness check, not a rendering check, and I had no category of tests for it.

---

### BUG-002 — Missing `postcss.config.js` (site completely unstyled)

**What test should have caught this:**
A build output verification test should have caught this. Specifically:

- A CI step or test asserting that the compiled CSS output file exceeds a minimum size threshold. A correctly compiled Tailwind stylesheet is ~31 kB; the broken build produced 1.38 kB (raw directives). A trivial file-size assertion on the build artifact would have caught this immediately.
- A smoke test that loads the rendered page in a headless browser and asserts that at least one element has a computed background-color or font-size different from the browser default — i.e., that styles are actually applied.
- A Playwright E2E visual check or even a basic assertion that a known Tailwind class (e.g. `bg-white`, `text-gray-900`) produces a non-default computed style on any element.

**What was missing:**
I had no build output verification step and no visual smoke tests. In R1, I wrote zero E2E or Playwright tests — the results file explicitly lists E2E (Playwright) for the login → MFA → publish journey as a "remaining gap." That gap also meant there was nothing to detect an entirely unstyled page. My testing scope was unit tests and component render tests only, which exercise React component logic in jsdom — jsdom does not compile CSS or apply Tailwind, so the PostCSS wiring failure was invisible to all of my existing tests.

**Why the tests did not catch this:**
jsdom, Vitest, and React Testing Library do not execute a real build pipeline, do not evaluate PostCSS, and do not apply stylesheets. My entire frontend test suite ran against jsdom, which means a catastrophic build-pipeline failure — one that produces a visually broken production artifact — would pass every one of my unit tests without issue. I had no layer of testing that touched the actual Vite build output.

---

## R1 Carry-over (still unresolved from R1)

**Coverage below 80%:**
Not resolved. The R1 results report shows post-R1 coverage at 55–60% for the API, ~45% for the web frontend, and ~45% for the CMS. All three repos remain below the 80% minimum required by the QA standards. The R1 report's own "Remaining Gaps" section lists 28 untested widgets in omnichat-v4-web, all 14 pages, the usePageContent and useNavigation hooks, live auth route integration tests, the preview token flow, media upload validation, and the ProfilePage password form. None of these were addressed before R2, because R2 was triggered by staging bugs — not by a planned coverage-improvement sprint.

**Mandatory auth integration tests missing:**
Not resolved. The R1 results note explicitly deferred live HTTP integration tests for `POST /v1/auth/login`, `POST /v1/auth/refresh`, and `POST /v1/auth/mfa/verify` on the grounds that a mock KV store and Drizzle schema fixtures had not been set up, and that CI was not yet wired. That deferral was reasonable in isolation but should have been logged as a blocking gap with a hard commitment to address before staging deployment — not a soft "recommended for the next testing sprint." These routes are the most critical paths in the system and they went to staging without integration-level coverage.

---

## Pattern Analysis

Four systemic gaps allowed these bugs through:

**1. No testing category for configuration correctness.**
My testing approach had two modes: unit tests for logic, and component render tests for UI. Neither mode exercises the question "is the app reading the right environment variable?" or "does this build artifact look correct?" BUG-001 is a configuration correctness failure. I had no test category that covers configuration — reading the right env var name, absence of hardcoded production URLs as fallbacks, and env var presence enforcement. This gap would also have missed BUG-004 (CORS_ORIGINS vs ALLOWED_ORIGINS) had the tester been implicated in that bug.

**2. No build artifact verification.**
BUG-002 is a build pipeline failure, not a code logic failure. My entire test suite runs against source code in jsdom. There is no step that (a) runs the Vite build, (b) inspects the output, or (c) loads the built artifact in a real browser. A missing postcss.config.js is completely undetectable at the unit test layer. I treated "build pipeline is someone else's problem" as an implicit assumption. That was wrong — the tester must own a build verification gate, especially for a frontend that depends on a PostCSS compilation step.

**3. E2E tests treated as optional rather than required.**
The QA standards require E2E tests for critical user journeys. The R1 results listed E2E as a remaining gap rather than a blocking deficiency. As a result, there was no layer of testing that would observe the application as a user would — in a real browser, with a real build, with real styles. Both BUG-002 (unstyled page) and BUG-001 (wrong API target) would likely have been caught by even a minimal E2E smoke test that (a) loaded the page and asserted it was not visually broken, and (b) intercepted outbound fetch calls and asserted the target domain.

**4. Deferral of integration tests without a hard gate.**
The live auth integration tests were deferred from R1 with a soft recommendation. There was no gate or escalation: nothing prevented the code from proceeding to staging without them. The tester role must either write the integration tests or formally block progression — not note the gap and leave it in a backlog.

---

## Commitments for R3

1. **Add a services-layer test for `api.ts`** that asserts `VITE_API_BASE_URL` is the variable read, that requests use the value of that variable, and that the service does not compile with a hardcoded production domain fallback. This test must pass before any frontend deployment proceeds.

2. **Add a build output verification step** — either a CI shell assertion or a Vitest build-integration test — that checks the compiled CSS output file size exceeds 20 kB after `vite build`. This is the minimum gate to catch a PostCSS pipeline failure.

3. **Add at least two Playwright E2E smoke tests** targeting the built and deployed staging URL: (a) assert the homepage has computed styles applied (not a bare unstyled page), and (b) assert that network requests to API endpoints use the staging base URL, not the production domain.

4. **Write the live auth integration tests** (`POST /v1/auth/login`, refresh, and MFA verify) using a mock KV store. These must be completed and passing before R3 closes — they are no longer deferrable.

5. **Establish a coverage gate in CI**: block merge to `develop` if any repo falls below 80% line coverage. This replaces the current soft reporting approach with a hard enforcement mechanism.

6. **Add a test category checklist to the tester agent's pre-sign-off checklist**: (a) configuration correctness tests present?, (b) build artifact verification present?, (c) E2E smoke tests present? If any are absent, the tester must either write them or formally log a blocking exception — no silent deferrals to backlog.

---

## Self-Score

Score: 1/5

**Justification:** Two Critical bugs that reached staging were directly caused by the absence of tests in my scope — a configuration correctness test for BUG-001 and a build artifact verification test for BUG-002. Both were entirely preventable with tests that were well within the tester role's responsibility. Neither was written, and neither was flagged as a gap in R1. On top of that, coverage remains below 80% across all three repos, the mandatory auth integration tests remain unwritten, and E2E tests were deferred from R1 without a hard commitment to resolve them before staging. The test suite that existed was of reasonable quality within its narrow scope, but that scope was far too narrow. The score reflects that my testing approach had structural gaps that allowed Critical-severity staging failures through.
