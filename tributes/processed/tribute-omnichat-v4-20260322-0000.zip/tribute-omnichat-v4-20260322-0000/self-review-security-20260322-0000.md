# Security Auditor Self-Review — R3 — 2026-03-22

## Round 3 Bug Batch Reference
artifacts/development/bug-report-20260322-0000.md

---

## Implicated Bugs

The security-auditor is not directly implicated in any of the four R3 bugs. The attribution table in the bug report lists: devops-engineer (BUG-03-001, BUG-03-003), compliance-officer (BUG-03-001), developer (BUG-03-002, BUG-03-003, BUG-03-004), code-reviewer (BUG-03-002, BUG-03-004), and ux-reviewer (BUG-03-004). The security-auditor is not named in any row.

However, BUG-03-001 has a tangential security angle that warrants honest analysis. The analysis follows.

---

## Tangential Security Angle — BUG-03-001: `VITE_API_BASE_URL` pointing to production URL on staging

**Bug summary:** The Vercel environment variable `VITE_API_BASE_URL` was set to `https://api.omnichat.ai` (the production API, with DNS not yet configured) on the staging deployment. All API calls from the staging web app went to an unresolved production hostname, returning connection errors.

### Security dimension of this bug

A misconfigured `VITE_API_BASE_URL` pointing to an uncontrolled or non-existent endpoint creates three security-adjacent risks:

1. **Request leakage to an uncontrolled endpoint.** If DNS for `api.omnichat.ai` had resolved to a third-party IP (e.g., via domain squatting, DNS hijack, or CDN misconfiguration during a transition period), all staging API requests — including authentication requests carrying credentials and cookie values — would have been transmitted to that uncontrolled origin. In the current project state this risk was theoretical (the domain does not yet resolve), but the pattern is a real attack vector in environments where production domains are partially live.

2. **Environment isolation failure (OWASP A05).** The OWASP A05:2021 Security Misconfiguration category explicitly covers the case of production configuration values being active in a non-production environment. An env var pointing staging sessions at a production endpoint violates the "Dev, staging, and production environments strictly separated" requirement in `security-checklist.md` and `agent_docs/generic/security-checklist.md`.

3. **Audit trail confusion.** If the production API had been reachable, staging-generated events (test logins, content edits, draft submissions) would have been written to production audit logs and databases, contaminating forensic evidence and data integrity.

### Should my R2 audit have flagged env var configuration as a security concern?

The R2 audit (artifacts/security/audit-20260321-0000.md) did not examine the Vercel project environment variable values for `VITE_API_BASE_URL`. It examined `vercel.json` for CSP headers (SEC-021, SEC-022) and the Cloudflare `wrangler.toml` for binding mismatches (SEC-001) and log level misconfiguration (SEC-013). The Vercel dashboard environment variable values are not stored in the repository — they are provisioned out-of-band by the devops-engineer during deployment setup.

**This is the key distinction:** `wrangler.toml` is a committed configuration file, readable in the codebase. Vercel environment variable values are not. A static codebase audit cannot directly inspect what values are set in the Vercel dashboard. The R2 audit scope was defined as "full codebase — `omnichat-v4-api`, `omnichat-v4-web`, `omnichat-v4-cms-web` — plus all infrastructure configs and CI/CD workflows." A Vercel dashboard env var is not part of the committed codebase or checked-in config files.

However, there is a partial responsibility that I should acknowledge:

**What the R2 audit did that was relevant:** The R2 audit found SEC-013, which flagged that the default `wrangler.toml` environment uses `CORS_ORIGINS = "http://localhost:5173,http://localhost:5174"` — and explicitly reasoned that if a developer runs `wrangler deploy` without `--env`, the production worker deploys with localhost CORS origins, breaking all deployed frontends. This demonstrates that my R2 audit scope included reasoning about what happens when environment-specific config values are wrong — not just whether values are structurally valid.

**The gap:** Having identified the class of risk "wrong environment values cause runtime failures and security misconfigurations," the R2 audit did not extend this reasoning to the frontend counterpart: "Does `VITE_API_BASE_URL` in the Vercel environment point to the correct environment-specific endpoint?" The deployment runbook (`agent_docs/project/deployment.md`) documents the staging API URL (`https://omnichat-v4-api-staging.stephen-api.workers.dev`). A cross-check between the documented staging API URL and the Vercel env var value — even as a checklist note — was within scope of environment separation verification.

**Honest assessment:** The R2 audit could not have directly read the Vercel dashboard env var value, so direct detection was not possible from the codebase alone. However, the audit could have — and did not — flag "Verify that `VITE_API_BASE_URL` is set to the staging API URL in the Vercel staging environment, not the production URL documented in `deployment.md`" as a deployment verification requirement. The R2 self-review (self-review-20260321-0001.md) committed to extending A05 checks to "all static configuration values that reference external services" — but Vercel env vars were not subsequently added to that check.

**Conclusion:** The security-auditor is not responsible for BUG-03-001. The misconfiguration occurred during devops provisioning in the Vercel dashboard, outside the audit's direct visibility. However, the audit could have produced a verification checklist item flagging the risk of production API URLs being copied into staging Vercel env vars, in the same way it flagged the `wrangler.toml` bare-deploy risk in SEC-013. Not producing that checklist item is a minor gap in the R2 audit's environment-separation coverage — an omission, not a miss on a directly observable fact.

---

## R2 Audit Quality Assessment

### Were R2 commitments honoured?

The R2 self-review made six commitments for R3:

1. **CSP domain verification** — The R2 audit (which is the artifact this self-review assesses; the R3 audit has not yet been performed) contained this commitment for future rounds. The R3 audit is being triggered now, so this commitment applies to the R3 audit execution, not to the R2 audit output.

2. **Environment-context config audit (A05)** — Partially honoured. The R2 audit found SEC-013 (wrangler.toml default env misconfiguration). It did not produce the Vercel env var verification checklist item described above. The gap is noted.

3. **Per-environment override strategy review** — Covered in the R2 audit via the existing CSP findings (SEC-021, SEC-022) and the discussion in SEC-013. Not expanded to Vercel env vars.

4. **Application-layer URL hardcoding** — The R2 audit did not find any new hardcoded production URLs in the frontend service layer beyond what was already fixed from R1. No new instances were introduced in R2 development. This commitment was satisfied by absence of new violations.

5. **Raise checklist gap to The Genesis** — This remains a commitment to be fulfilled. Not yet actioned.

6. **Re-score honestly** — The revised R1 score of 4/5 was accepted and recorded in the R2 self-review.

### R2 audit coverage against R3 bugs

| R3 Bug | Security dimension | Was it in R2 audit scope? | Did R2 audit flag it? | Assessment |
|---|---|---|---|---|
| BUG-03-001 (wrong API URL env var) | Request leakage, A05 env isolation | Partially — env var not in codebase; risk class covered by SEC-013 logic | No — no verification checklist item for Vercel API URL env var | Minor omission — not a direct miss |
| BUG-03-002 (Promise.all SEO crash) | No direct security dimension — availability/UX issue | Outside security audit scope | N/A | Not in scope |
| BUG-03-003 (empty staging DB) | No direct security dimension — staging data provisioning | Outside security audit scope | N/A | Not in scope |
| BUG-03-004 (i18n not integrated) | No direct security dimension — UI localisation | Outside security audit scope | N/A | Not in scope |

BUG-03-002, BUG-03-003, and BUG-03-004 are functional, DevOps, and front-end architecture issues with no material security surface. They are correctly attributed to developer, code-reviewer, devops-engineer, and ux-reviewer. The security-auditor has no reasonable responsibility for them.

### R2 audit strengths (maintained from R1)

- All 26 findings from R1 remained accurate — no false positives were identified in the R2 development cycle.
- Five BLOCKER findings remain correctly scoped and none have been contested by the development team as inaccurate.
- SEC-001 (KV binding mismatch) was the highest-impact finding — without it, rate limiting and account lockout would have been silently disabled in production. That finding stands as the primary value delivered by the R2 audit.
- SEC-016 (CMS audit client calling `/v1/audit-log` vs `/v1/audit`) continues to represent the class of finding where frontend/backend contract cross-checking catches silent functional failures in security tooling.

### Honest score assessment for R2 audit

The R2 audit was a re-run on the R1 codebase plus any new R2 changes. No new security findings were produced in the R2 audit artifact (the same 26 findings from R1 were carried forward with no additions). The R3 bugs do not implicate the security-auditor directly. The only gap is the absence of a Vercel env var verification checklist item — a minor omission given that the value was not readable from the codebase.

**R2 audit score: 4/5.** Maintaining the R1 revised score. The R2 audit produced no new misses on directly observable facts; the one gap (Vercel env var coverage) is consistent with the limitation acknowledged in the R2 self-review regarding out-of-band provisioning values.

---

## Process Changes

1. **Add Vercel env var verification to the security audit checklist.** For any project deploying to Vercel, the security audit must include a step: "Request confirmation from devops-engineer that all Vercel environment variables pointing to external services (`VITE_API_BASE_URL`, `VITE_*_URL`, OAuth redirect URIs, analytics keys) are set to the correct environment-specific values — staging values in the staging Vercel environment, production values in the production Vercel environment." This check cannot be performed from the codebase alone and must be treated as a handshake with the devops-engineer role. Flag any unconfirmed env var as an open A05 risk item.

2. **Extend SEC-013 class of finding to all platforms, not only Cloudflare.** The reasoning in SEC-013 ("deploying without --env uses default values designed for local development") applies equally to Vercel (`vercel env` commands and the deployment preview system). Future audits should produce a companion finding noting that Vercel environment configuration requires the same level of explicit per-environment verification as `wrangler.toml`.

3. **Raise The Genesis checklist gap (R2 commitment, now overdue).** Submit a retrospective improvement proposal to add to `agent_docs/generic/security-checklist.md`:
   - Under "CORS & Headers": `[ ] CSP directive domain values verified against the documented API base URL and CDN origin for the target deployment environment`
   - Under "Deployment Configuration": `[ ] All platform environment variables (Vercel, Cloudflare, Railway, etc.) pointing to external services confirmed as environment-specific — no production URLs in staging config, no staging URLs in production config`

4. **Formalise a cross-role verification step for out-of-band config.** Values that are provisioned outside the codebase (Vercel dashboard, Cloudflare Workers Secrets, Neon connection strings) are not auditable from source code alone. The security audit should produce an explicit "unverifiable from codebase" section listing these values and flagging them as requiring devops-engineer or compliance-officer confirmation before a security PASS verdict is issued.

---

## Commitments for R4

1. **Execute the R3 security audit against the current codebase**, applying all prior commitments: CSP domain value verification, environment-context config audit, per-environment override strategy review, and application-layer URL hardcoding sweep.

2. **Produce a "requires out-of-band confirmation" section** in the R3 audit artifact, listing all Vercel env vars, Cloudflare secrets, and Neon connection strings that could not be verified from source code, with a recommendation for devops-engineer confirmation before any environment is cleared for production use.

3. **Action the Genesis checklist gap** identified in R2 and confirmed again in this self-review. Draft the two checklist items and submit via the retrospective improvement process to The Genesis.

4. **Verify that all R1/R2 BLOCKER and HIGH findings have been remediated** before issuing a new security verdict. The R3 audit should confirm: SEC-001 (KV binding), SEC-002 (dangerouslySetInnerHTML sanitisation), SEC-003 (forgot-password rate limiting), SEC-004 (MFA brute-force protection), and SEC-005 (audit log cursor direction) are the five blockers — all must be resolved or have accepted mitigations before a PASS verdict is possible.

5. **Maintain honest scoring.** If the R3 audit produces no new misses on directly observable facts, the 4/5 score is appropriate to carry forward. If the R3 audit misses a directly observable finding that surfaces in R4 bugs, the score should be revised downward with the same rigour applied in R2.

---

## PILOT STATUS
STATUS: COMPLETE
ARTIFACTS: artifacts/security/self-review-20260322-0000.md
