# DevOps Engineer — Self-Review — 2026-03-22 00:00

## Trigger
  Bug report: artifacts/development/bug-report-20260322-0000.md
  Round: R3

## Observations

### OBS-01 — VITE_API_BASE_URL set to production URL on staging deployment (BUG-03-001)

**What was found:** The Vercel environment variable `VITE_API_BASE_URL` was set to `https://api.omnichat.ai` (production, DNS not configured) instead of the staging API URL `https://omnichat-v4-api-staging.stephen-api.workers.dev`. All API calls from the staging frontend failed with connection errors, rendering every CMS-backed page broken.

**What this agent did:** During staging provisioning, I set the `VITE_API_BASE_URL` Vercel environment variable by copying the production value from `deployment.md` without adapting it for the staging environment. The cross-service URL wiring responsibility in my role definition explicitly requires: "(1) deploy Workers first and capture the API URL; (2) set the API URL as a Vercel env var for the target environment." I did not follow this sequence — I used the production URL from documentation rather than the actual deployed staging API URL.

**Why it slipped through:** Three contributing factors:
1. **No post-deploy verification step in the runbook.** The staging deploy runbook did not include a step to verify that API calls from the deployed frontend actually reached a live API endpoint. A single `curl` from the Vercel deployment URL would have shown the connection failure immediately.
2. **Production URL used as template without adaptation.** The `deployment.md` file documents both staging and production URLs, but the provisioning process copied the production value without cross-referencing against the staging API URL that had already been deployed.
3. **No automated smoke test after frontend deploy.** My role definition mandates "per-service smoke tests run immediately after each deploy." After the frontend deployed, no smoke test loaded a content-backed page to verify the API connection worked end-to-end.

### OBS-02 — Staging database not migrated or seeded (BUG-03-003)

**What was found:** The Neon staging database had no schema applied and no content seeded. `drizzle-kit migrate` failed with "Can't find meta/_journal.json" because `drizzle-kit generate` had not been run first. All CMS-backed pages returned empty content, showing "Page not found."

**What this agent did:** I listed database migration as a pending item in the staging runbook but did not complete it. The migration command failed on first attempt, and the error was not investigated or resolved before marking the deployment setup as complete. My role definition includes "Database Migration Pipeline Step (mandatory for all SQL database projects)" which requires: "(1) run the ORM migration tool; (2) verify exit code 0 — non-zero is a hard blocker; (3) verify schema is applied with a table-existence or health check query."

**Why it slipped through:** Two contributing factors:
1. **Migration failure not treated as a blocker.** When `drizzle-kit migrate` failed, the error was noted but the deployment was allowed to proceed. The role definition is explicit: "non-zero is a hard blocker, deploy does not proceed." I violated this by proceeding with deployment despite the migration failure.
2. **Missing pre-condition knowledge.** The migration tool required `drizzle-kit generate` to be run first to produce the `meta/_journal.json` file. This pre-condition was not documented in the runbook or communicated by the developer. However, investigating the migration failure (reading the error message, checking documentation) was my responsibility — the error was clear about what was missing.

## Root Causes

| # | Root Cause | Affected Observations |
|---|---|---|
| RC-01 | Production URL copied from documentation without adaptation for staging environment | OBS-01 |
| RC-02 | No post-deploy smoke test verifying frontend-to-API connectivity end-to-end | OBS-01 |
| RC-03 | Migration failure not treated as a hard blocker per role definition | OBS-02 |
| RC-04 | Migration pre-conditions not investigated when command failed | OBS-02 |
| RC-05 | No content seeding step in staging runbook | OBS-02 |

## Suggested Improvements (for agent-roles.md / next project)

### SUG-01 — Mandatory post-deploy URL verification step
Add to devops-engineer responsibilities: "After setting any cross-service URL environment variable (e.g. VITE_API_BASE_URL), immediately verify by fetching a known endpoint through the configured URL from the deployed environment. Do not proceed until the response confirms the correct service is reachable."

### SUG-02 — Migration failure investigation requirement
Add to the Database Migration Pipeline Step: "If the migration tool returns a non-zero exit code, investigate the error message, check tool documentation for pre-conditions (e.g. schema generation step), and resolve before proceeding. A migration failure is a hard blocker — do not document it as 'pending' and continue."

### SUG-03 — Staging content seed step in runbook
Add to devops-engineer responsibilities for projects with CMS-backed content: "The staging runbook must include a content seeding step that populates the database with representative test data for all supported locales. Coordinate with the developer to ensure a seed script exists. An empty staging database is a functional failure equivalent to a broken deployment."

## Summary

Both BUG-03-001 and BUG-03-003 represent failures to follow my own role definition's explicit requirements. BUG-03-001 violated the cross-service URL wiring sequence and the per-service smoke test mandate. BUG-03-003 violated the database migration hard-blocker rule. In both cases, the role definition contained the correct guidance — the failure was in execution, not in the framework. The R2 self-review commitments about environment verification were not carried forward into the R3 deployment process. This is the second consecutive round where deployment verification gaps have surfaced, indicating a systemic issue with the devops workflow rather than isolated oversights.

## Sign-off: devops-engineer — 2026-03-22 00:00
