# Developer — Self-Review — 2026-03-22 00:00

## Trigger
  Bug report: artifacts/development/bug-report-20260322-0000.md
  Round: R3

---

## Observations

### OBS-01 — SEO fetch made a hard blocking dependency via `Promise.all`

**What was found:** Every page on staging rendered "Unable to load content" because `usePageContent.ts:33` used `Promise.all([getPageContent(pageId, lang), getPageSeo(pageId, lang)])`. When the SEO endpoint returned 404 (no page record seeded in the DB), `Promise.all` rejected immediately, causing `isError` to be set to `true` and the entire page to enter its error state — even though `getPageContent` had returned a valid 200 response.

**What this agent did:** I wrote `usePageContent.ts` with `Promise.all` treating both the content fetch and the SEO fetch as equal-weight dependencies. A failure in either would fail the whole hook. SEO metadata is supplementary information — it decorates a page but it is not required for the page to render. I did not apply `.catch(() => null)` to the SEO call, and I did not write a test that exercised the case where content succeeds but SEO returns 404.

**Why it slipped through:** I treated SEO as functionally equivalent to content when designing the data-fetching strategy. I did not reason about the failure modes of each dependency independently. The correct mental model is: content failure = page cannot render; SEO failure = page renders with fallback metadata. I also did not write a unit test for `usePageContent` covering the partial-failure scenario (content OK, SEO 404), which would have caught this immediately. The five existing widget tests in the test suite test rendering output, not the hook's error-isolation behaviour. The gap was invisible in local development because my local dev environment had no seeded data and I was not exercising the hook against a live API — I had no running integration environment to discover the failure in.

---

### OBS-02 — No seed script provided for staging database

**What was found:** After BUG-03-001 (wrong Vercel env var) and BUG-03-002 (SEO blocking page render) were fixed, all content pages still showed "Page not found" because the Neon staging database had no content rows. The content API returned valid 200 responses with `fields: {}`, which caused `usePageContent` to set `isEmpty: true` and render the not-found state. Additionally, the `drizzle-kit migrate` step in the staging runbook had failed in the previous session ("Can't find meta/_journal.json") because `drizzle-kit generate` had not been run first, meaning the DB schema itself may not have existed.

**What this agent did:** I delivered a migration file (`migrations/0001_initial_schema.sql`) and documented a `psql` migration command in section 5 of my R1 development notes. I noted in the R1 "Next Steps" section (item 6) that the database needed to be seeded with "initial locale and widget_type records." I did not write a seed script. I listed seeding as a next step rather than as a deliverable that was required before the staging environment could function. I also did not raise the missing `drizzle-kit generate` pre-step as a risk or a blocker for the devops deployment runbook.

**Why it slipped through:** I mentally categorised the seed script as an operational convenience rather than as a prerequisite for any functional testing of the site. This was wrong: without at least one page record and its associated content, the entire public website renders nothing — the seed script is not optional for staging, it is the minimum viable data set for any functional test. I acknowledged the gap in my own artefact ("Next Steps, item 6") but assigned it no owner, no priority, and no blocking status. Because I framed it as a recommendation rather than a deliverable, neither the devops-engineer's runbook nor the compliance checklist treated it as a required step. I also did not communicate to the devops-engineer that the migration tooling required `drizzle-kit generate` before `drizzle-kit migrate`, creating a silent pre-condition that was undocumented in the runbook.

---

### OBS-03 — i18n infrastructure built but never integrated into components

**What was found:** Language switching on the deployed staging site updated only CMS-driven content (fields delivered via `getField` from the content API). All surrounding UI text — navigation labels, button text, page body copy, section headings, error states, footer — remained in English regardless of the selected locale. Investigation showed that `useTranslation()` / `t()` was called in exactly 1 out of approximately 20 widgets (`ImageGallery.tsx`). Zero page components used `t()`. All UI text in page components and the remaining 19 widgets was hardcoded in English JSX strings.

**What this agent did:** I built the full i18n infrastructure: `src/i18n/index.ts` configures react-i18next with `HttpBackend`, translation JSON files exist for all 7 locales with correct translations for UI string keys, `LocaleGuard` wraps the app, and `useLocale` manages the `oc_lang_pref` localStorage preference. I then wrote 14 page components and 33 widgets in the same session, hardcoding English strings throughout, and used `t()` in only one widget. I did not integrate the infrastructure I had built into the code that needed it.

**Why it slipped through:** I built the i18n infrastructure in an early phase of the session and then pivoted to building pages and widgets, treating each widget as a standalone rendering component. As I implemented each widget, I wrote the JSX with literal English strings — the path of least resistance — without cross-referencing the translation files I had already created or applying the `t()` calls I had already demonstrated in `ImageGallery.tsx`. I did not run a final integration check asking "does every user-facing string in every component route through `t()`?" before declaring the feature complete. The test suite did not catch this because the widget tests (`HeroBanner`, `AccordionFaq`, `HubSpotForm`, `StatsNumbers`, `TabContent`) mock `useTranslation` via `vi.mock('react-i18next')` and assert on the English string values directly — they would pass whether the strings came from `t()` or were hardcoded, because the mock returns the key unchanged. The tests confirmed rendering output but did not verify that `t()` was actually being called. I should have written at least one test per widget that explicitly asserted on `t()` being invoked with the expected key, or performed a manual language-switch test on the built app before sign-off. I did neither.

---

## Root Causes

| # | Root Cause | Affected Observations |
|---|---|---|
| RC-01 | No per-dependency failure mode analysis when composing async data fetches. Both data sources were treated as equal-weight hard dependencies without asking: "what does the page still need to render if this specific call fails?" | OBS-01 |
| RC-02 | No unit test covering partial-failure states of `usePageContent` (content OK + SEO 404). The existing test suite covered widget rendering output but not the data-fetching hook's error isolation behaviour. | OBS-01 |
| RC-03 | Known gaps documented as "Next Steps" rather than as blocking deliverables. Framing seeding as a recommendation rather than a required prerequisite meant no agent in the pipeline treated it as a blocker, and no owner or completion criterion was assigned. | OBS-02 |
| RC-04 | Undocumented migration tooling pre-conditions (drizzle-kit generate before migrate) were not communicated to the devops runbook, leaving a silent failure mode in the deployment process. | OBS-02 |
| RC-05 | No end-to-end integration check for i18n coverage. Infrastructure was built and then used inconsistently during component implementation, with no final pass to verify that every user-facing string routes through `t()`. | OBS-03 |
| RC-06 | The i18n mock strategy in widget tests (mocking `useTranslation` and asserting on English string values) made tests pass regardless of whether `t()` was called, providing false coverage confidence for the i18n integration requirement. | OBS-03 |

---

## Suggested Improvements (for agent-roles.md / next project)

### SUG-01 — Mandatory partial-failure test for every data-fetching hook

Any hook that composes multiple async data sources must include a test case where a secondary source fails (non-2xx or network error) and the primary data is still available. The test must assert that `isError` remains false and the component renders successfully with fallback values for the failed secondary source. This test must exist before the hook is marked delivered.

### SUG-02 — Distinguish "supplementary" from "required" data sources in hooks

When writing a hook that fetches multiple endpoints, the developer must explicitly classify each source as either "page-blocking" (failure prevents render) or "supplementary" (failure degrades gracefully). Supplementary fetches must use `.catch(() => null)` or equivalent error isolation. This classification must be documented in the hook's JSDoc comment so reviewers can verify it matches the intent.

### SUG-03 — Seed script is a required deliverable for any DB-backed feature, not a next-step recommendation

Whenever a feature requires database content to be functionally testable (pages, content items, widget types, locales), a seed script must be delivered in the same pipeline stage as the migration and application code. If no seed script exists, the feature must be listed as "not functionally testable" in the development notes — never as "complete." A feature marked complete must be demonstrable against the staging environment with the delivered seed data.

### SUG-04 — Migration tooling pre-conditions must be explicitly documented in the development notes run instructions

Any multi-step migration process (e.g. "generate then migrate") must have each step listed in order in the run instructions section of the development notes artefact, with the consequence of skipping a step noted. A single "run migration" instruction that silently requires a preceding step is a runbook defect.

### SUG-05 — i18n completeness check: all user-facing strings must use `t()` before sign-off

Before declaring any page or widget component delivered in a project with i18n requirements, the developer must verify that every user-facing string in JSX is wrapped in `t()`. This check can be a simple grep for hardcoded string literals in JSX attribute values and JSX text nodes across the component file. Zero hardcoded English strings should exist in rendered output in any widget or page component.

### SUG-06 — i18n mock tests must assert on `t()` invocation, not on string output

Widget tests that mock `react-i18next` must assert `expect(mockT).toHaveBeenCalledWith('expected.key')` in addition to (or instead of) asserting on the rendered string value. Asserting only on the rendered English string provides no coverage signal for whether `t()` was actually called — the test passes equally for a hardcoded string and a `t()` call when the mock returns the key unchanged.

---

## Summary

Three bugs this round were my direct responsibility. BUG-03-002 was a data-fetching design error: I used `Promise.all` without isolating the SEO fetch from the content fetch, making a supplementary data source into a page-blocking dependency. The fix was a single `.catch(() => null)`, which I should have applied at the time of writing. The root cause was not reasoning about failure modes per dependency. BUG-03-003 was a scope misclassification error: I identified the seeding gap myself in my R1 artefact but categorised it as a recommendation rather than a blocking prerequisite, so it had no owner and was not completed. BUG-03-004 was an integration completion error: I built a full i18n infrastructure and then failed to apply it to the 33 widgets and 14 pages I wrote in the same session, using `t()` in exactly 1 of 20 components. The test suite did not catch this because the mock strategy for `useTranslation` confirmed rendering output rather than `t()` invocation. All three bugs were discoverable with a basic functional walkthrough of the deployed site — they were not subtle. A manual language-switch test and a check of any content-backed page on staging would have surfaced all three before the round closed.

The pattern from R2 (insufficient verification before sign-off) has recurred in a different form. In R2 the failure was not running the build and inspecting output. In R3 the failure was not running a functional walkthrough against the deployed environment — not clicking through a language switch, not visiting a content page, not verifying that `t()` was wired into the components that needed it. Declaring a deliverable complete must require demonstrating it works in the deployed environment, not just that the code compiles and unit tests pass.

---

## Sign-off: developer — 2026-03-22 00:00
