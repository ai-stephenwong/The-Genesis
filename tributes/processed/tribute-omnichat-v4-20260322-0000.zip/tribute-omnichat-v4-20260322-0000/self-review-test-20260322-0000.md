# tester — Self-Review — 2026-03-22 00:00

## Trigger
  Bug report: artifacts/development/bug-report-20260322-0000.md
  Round: R3

---

## Observations

### OBS-01 — BUG-03-001: VITE_API_BASE_URL pointing to production URL on staging was not caught by smoke tests

**What was found:** The Vercel staging deployment had `VITE_API_BASE_URL` set to `https://api.omnichat.ai` (the production domain, which does not yet exist), causing every API call from the staging frontend to fail with a connection error. All CMS-backed pages displayed "Unable to load content."

**What this agent did:** The R2 test results (`results-20260321-0000.md`) acknowledged the need for smoke tests that intercept outbound fetch calls and assert the target domain. Specifically, the R2 self-review (`self-review-20260321-0001.md`) committed to: "Add at least two Playwright E2E smoke tests targeting the built and deployed staging URL: (a) assert the homepage has computed styles applied, and (b) assert that network requests to API endpoints use the staging base URL, not the production domain." These smoke tests were not written. The R2 results report shows a "Remaining Gaps" section that lists E2E tests as absent, and the commitments from the R2 self-review were not acted on before this staging round.

**Why it slipped through:** The smoke tests committed to in R2 were never written. The R3 results artifact (`results-20260321-0000.md`) shows no Playwright tests and no services-layer test for `api.ts` URL configuration — both of which were explicitly committed to in R2. The tester's responsibilities include "Cross-service smoke tests" that verify the frontend → API connection in the deployed environment. That smoke test would trivially detect this failure: a request from the staging frontend to any API endpoint would have either timed out (no route to `api.omnichat.ai`) or returned a connection error, which would have failed the smoke test. No such test existed.

---

### OBS-02 — BUG-03-002: SEO endpoint 404 crashing all pages was not caught by E2E or integration tests

**What was found:** `usePageContent` used `Promise.all([getPageContent, getPageSeo])`, making SEO a blocking dependency. A 404 from the SEO endpoint (no CMS data seeded) caused every page to fail with "Unable to load content", even when content data was available.

**What this agent did:** The R3 test results show that `usePageContent` was explicitly listed as untested — the results file states "28 untested widgets, 14 pages, usePageContent hook, useNavigation hook" under gaps. No hook test for `usePageContent` was written despite this being a critical data-fetching hook on which every page depends. No E2E test loaded a page against the staging API to observe real rendering behaviour. The tester's responsibilities include verifying "each functional requirement has test coverage" — pages rendering correctly with and without CMS data is a clearly stated functional requirement.

**Why it slipped through:** The `usePageContent` hook was entirely untested. A unit test for this hook would have tested the error isolation behaviour of the `Promise.all` call and would have found that a rejected SEO promise causes the entire hook to return an error state — exactly this bug. Such a test was not written. Beyond unit coverage, an E2E test that navigated to any page on the deployed staging site would have observed the "Unable to load content" failure immediately. Neither existed.

---

### OBS-03 — BUG-03-003: Empty staging database not detected by smoke tests

**What was found:** The staging Neon database had no schema migrations run and no content seeded. All CMS-backed pages returned valid 200 responses with empty `fields: {}`, causing `usePageContent` to set `isEmpty: true` and render the "Page not found" state.

**What this agent did:** The tester's responsibilities include "Cross-service smoke tests" that verify "at least one full frontend → API → database round-trip." This is explicitly defined in agent-roles.md §6. A smoke test that loaded any content-backed page and asserted that the response contained non-empty `fields` would have caught this. No such smoke test existed. The R3 test results contain no smoke test category whatsoever — no deployment sanity check run, no cross-service round-trip test, no CORS preflight test.

**Why it slipped through:** The tester did not run any tests against the deployed staging environment. The R3 results are entirely unit and component tests run in jsdom — not a single test touched a real deployed service. The agent-roles.md §6 requirement for a cross-service smoke test (frontend → API → database) was not fulfilled. A smoke test hitting `GET /v1/public/content/book-a-demo/ja` against the staging API would have returned `{ fields: {} }`, which should have failed the test with an "empty content" assertion. That test was not written.

---

### OBS-04 — BUG-03-004: i18n not integrated into page components — language switch testing absent

**What was found:** All page components and most widgets had hardcoded English strings rather than `t()` calls, meaning the language switcher only affected CMS-driven content. The i18n infrastructure was fully set up but unused across ~20 widgets and all 14 pages.

**What this agent did:** The R3 test results show [TEST-012] for `useLocale` and [TEST-013] for i18n rendering in `HeroBanner`. These tests verified that `i18n.changeLanguage()` is called on locale switch and that CJK content renders correctly. However, none of the tests verified that a non-CMS string (e.g. a hardcoded button label or navigation item) changes to the target locale's translation when the language is switched. The test for `useLocale` tested the hook's mechanics (localStorage write, navigate call, GA4 event) but did not render any page component and assert that UI text was translated. No test covered the integration point between the language switch and the rendered UI strings.

**Why it slipped through:** The i18n tests were scoped to infrastructure verification (does `i18n.changeLanguage()` get called?) rather than end-to-end rendering verification (does the UI text actually change?). A proper i18n integration test would have rendered a page component or widget, called `switchLocale('ja')`, and asserted that a known English string was replaced by its Japanese equivalent. That test would have immediately found that `t('nav.solutions')` was never called — "Solutions" was hardcoded in `NavigationHeader.tsx`. The tester defined the i18n test scope too narrowly, stopping at hook mechanics rather than UI output verification.

---

## Root Causes

| # | Root Cause | Affected Observations |
|---|---|---|
| RC-01 | R2 commitments not actioned — Playwright E2E smoke tests and services-layer `api.ts` test committed to in the R2 self-review were not written before R3 | OBS-01 |
| RC-02 | No tests executed against deployed staging environment — all R3 tests ran in jsdom; no test touched a real deployed service; deployment sanity check and cross-service smoke tests required by the role definition were absent | OBS-01, OBS-02, OBS-03 |
| RC-03 | Critical hooks left untested — `usePageContent` is the primary data-fetching hook for every page; it was explicitly noted as untested in R2 and remained untested in R3 | OBS-02 |
| RC-04 | i18n tests scoped to hook mechanics rather than UI rendering output — tests confirmed the language-switch mechanism fires but did not assert translated strings appear in rendered components | OBS-04 |
| RC-05 | No blocking gate on deferred items — gaps explicitly carried forward from R2 (Playwright E2E, `usePageContent`, services-layer tests) were re-listed as "remaining gaps" rather than enforced as pre-staging blockers | OBS-01, OBS-02, OBS-03 |

---

## Suggested Improvements (for agent-roles.md / next project)

### SUG-01 — Require a pre-staging smoke test gate before any environment is marked ready for functional testing

The tester must execute a staged-environment smoke test before the compliance-officer or master conduct any functional review. The smoke test must cover: (1) deployment sanity check (`GET /health` with causality and commit SHA checks), (2) CORS preflight from the frontend origin, (3) at least one content-backed page load that returns non-empty `fields`, (4) network request origin assertion — all API calls from the frontend must target the environment's API URL, not a production or localhost URL. If any of these fail, the environment must be flagged as not ready for review and the tester must block further pipeline activity against it.

### SUG-02 — Require `usePageContent` (or the project's primary data-fetching hook) to be tested before any page ships

Any hook used by the majority of pages is a critical path. The tester must write tests for it that cover: empty response handling, error handling from each individual API call (not just `Promise.all` success), and loading state transitions. This must be required before the hook's first usage reaches staging.

### SUG-03 — Require i18n integration tests to verify rendered UI strings, not just hook mechanics

For any frontend project with i18n, the tester must write at least one test per page template (not per page instance) that: renders the page component with a non-default locale, and asserts that at least one non-CMS UI string (button label, nav item, section heading) matches the expected translation for that locale. A test that only asserts `i18n.changeLanguage()` was called is insufficient — it does not verify the strings are bound to the i18n system at all.

### SUG-04 — Self-review commitments must be tracked as blocking items, not backlog suggestions

When a tester's self-review lists a commitment (e.g. "write Playwright smoke tests before R3"), those commitments must be converted into a blocking pre-condition for the next round's sign-off, not re-listed as "remaining gaps." The tester's results artifact should include a "Commitments from prior self-review" section that marks each prior commitment as either DONE or BLOCKED (with escalation reason) before the results artifact can be marked COMPLETE.

---

## Summary

All four R3 bugs were catchable by the tester. BUG-03-001 and BUG-03-003 required smoke tests against the deployed staging environment — tests that are explicitly required by the tester's role definition and that were committed to in the R2 self-review. Neither was written. BUG-03-002 required a unit test for `usePageContent`, a hook explicitly listed as untested since R1 and still untested in R3. BUG-03-004 required i18n integration tests that verified rendered UI strings, not just hook mechanics — the tests written verified the mechanism but not the output. The common thread across all four is the same as in R2: commitments were made and not kept, and a gap between jsdom unit testing and real deployed-environment testing was never closed. This is the second consecutive round in which staging bugs were found by the master rather than the tester.

## Sign-off: tester — 2026-03-22 00:00
