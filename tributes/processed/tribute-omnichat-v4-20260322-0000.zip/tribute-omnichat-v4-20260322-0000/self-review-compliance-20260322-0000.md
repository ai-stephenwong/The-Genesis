# Compliance Officer Self-Review — R3 — 2026-03-22

## Round 3 Bug Batch Reference
artifacts/development/bug-report-20260322-0000.md

---

## Implicated Bugs

### BUG-03-001 — `VITE_API_BASE_URL` Vercel env var set to production URL on staging deployment

**What went wrong:**

In `compliance-20260321-0001.md` I issued a PASS verdict and declared the build "cleared for staging deployment." BUG-03-001 was discovered the following session when the master performed a functional walkthrough of the live staging URL. Every content-backed page returned "Unable to load content, Page not found" because the deployed web app was making all API calls to `https://api.omnichat.ai` — a production domain with no DNS configured — instead of the staging API at `https://omnichat-v4-api-staging.stephen-api.workers.dev`.

**What I committed to in R2 that I did not do:**

My R2 self-review (`self-review-20260321-0001.md`) made five explicit commitments for R3. The one most directly implicated in BUG-03-001 was Commitment 3:

> "Live integration smoke test documented in every PASS verdict. The re-check report will include a completed Integration Smoke Test Results table as required by `agent-roles.md`. Specifically: full auth flow on the live staging URL, at least one API-driven page load, verification that API calls are reaching the staging API (not production) via network log or response data inspection. No PASS verdict will be issued without this table completed."

This commitment was not honoured. `compliance-20260321-0001.md` contains no Integration Smoke Test Results table. No live staging URL was accessed. No API-driven page load was tested. No network log was inspected to verify which endpoint was being called. The PASS verdict was issued entirely on the basis of source code inspection.

Commitment 2 was also not honoured:

> "Staging environment correctness check as an explicit gate item. The compliance re-check will include a dedicated section: 'Staging Environment Isolation Verification.' This will verify that every env var referenced in the frontend service layer, the API worker, and the deployment manifests points to the correct staging service and not a production URL."

The re-check report has no such section. The `VITE_API_BASE_URL` Vercel environment variable was never checked against the staging API URL. If it had been, the misconfiguration would have been found before the PASS was issued.

**Why this happened — the actual gap:**

The R2 self-review correctly identified the process failure and made the right commitments. The R3 compliance report then repeated the same process failure the commitments were designed to prevent. That gap requires an honest explanation.

The R3 re-check was structured identically to the R2 re-check: I verified that the five blocking issues from the previous cycle were resolved in source code, reviewed test coverage, reviewed tech debt status, and issued a PASS. The Deployment Readiness Statement in `compliance-20260321-0001.md` explicitly authorised staging deployment. At no point did I open a browser, access the Vercel deployment URL, load a content-backed page, or inspect an API call in a network log.

The root cause is that the live smoke test requirement from `agent-roles.md` was treated as aspirational process improvement rather than as a gate condition. I documented the commitment, but at the point of issuing the PASS verdict I reverted to the artifact-inspection pattern — the same pattern that produced the R2 failure. The commitment existed on paper; the habit did not change.

**Why the env var misconfiguration was not caught by artifact review:**

BUG-03-001 differs from BUG-001 in R2 (the `VITE_API_URL` / `VITE_API_BASE_URL` key name mismatch) in an important way. In R2, the wrong variable name was visible in source code and was present in the tech debt log as TD-009. I had a document-level signal I failed to consequence-test correctly.

In R3, the defect was not in source code at all. The code correctly reads `VITE_API_BASE_URL` — the fix from R2 was applied. The defect was in the Vercel project environment variable configuration: the variable existed with the right name but the wrong value (the production URL). That value lived in the Vercel dashboard, not in any file in the repository. No code reviewer, security auditor, or tester had any basis to flag it from source inspection alone.

This is the category of defect that is structurally invisible to artifact-only review. It can only be caught by one of two methods:

1. A live integration smoke test that actually loads a content-backed page from the deployed staging URL and confirms the API response comes from the staging service.
2. An explicit environment variable audit step that reads the deployed configuration from the Vercel CLI (`vercel env ls`) and compares each variable value against the expected staging values documented in `deployment.md`.

Neither method was performed. That is the gap. Source code was clean; the deployment configuration was wrong; no check capable of detecting deployment configuration errors was run.

**Why the live smoke test was not performed despite the R2 commitment:**

There is no technical reason the smoke test could not have been performed. The staging URL was available. The Vercel deployment had completed. The requirement was explicitly documented in `agent-roles.md` and repeated in my own R2 self-review commitment. The honest assessment is that the compliance re-check workflow was executed as a document-review workflow — read artifacts, verify findings, issue verdict — without a structural forcing function that required a live URL to be opened before the PASS could be written. The commitment was present in the self-review artifact but was not embedded into the re-check checklist as a hard gate. As a result, it was possible to complete a "thorough" re-check — verifying all five blockers with evidence, reviewing all 15 tech debt items, writing a detailed Deployment Readiness Statement — without ever running a live test. The process allowed the PASS to be issued without the smoke test. That is the structural failure.

---

## PASS Verdict Re-assessment

The PASS verdict issued in `compliance-20260321-0001.md` does not retain full integrity.

The verdict correctly identified that all five blocking issues from the previous cycle were resolved in source code, and that assessment remains accurate — the code fixes were real. However, a PASS verdict for a staging deployment carries an implicit claim that the deployed staging environment functions correctly end-to-end. That claim was not verified. The deployed environment was in a broken state: all API calls from the live staging site were going to a non-existent production endpoint. Any QA activity performed against the staging URL during the period covered by the PASS would have been testing a non-functional environment.

The PASS verdict therefore overstated the quality of the staging deployment. It was accurate for source code. It was not accurate for the deployed system. Those are not the same thing, and the role definition for compliance-officer makes this explicit: the Live Integration Smoke Test is a pre-condition for any PASS verdict, not an optional enhancement.

**What the smoke test would have found:**

Any content-backed page load — for example, `GET /ja/platform/features/` — would have triggered an API call to `VITE_API_BASE_URL/v1/public/content/...`. With the variable set to `https://api.omnichat.ai`, that request would have failed with a DNS resolution error or a connection timeout. The page would have rendered the "Unable to load content" error state. This would have been immediately visible in the browser and immediately actionable: check network tab, observe request URL, compare against expected staging API URL, identify misconfiguration, escalate before issuing PASS. Total time to detect: under two minutes.

The smoke test is not a burdensome step. Its absence allowed a critical defect to pass through the compliance gate and reach the master's attention in the next session.

---

## Overall R3 Compliance Review Quality Assessment

**Strengths:**

- The five blocking issues from R2 were correctly verified with specific evidence (file paths, line numbers, test names, assertion text). The code-level fixes were real and the verification was accurate.
- The 15 tech debt items were correctly carried forward and their status was accurately reported.
- The security section was thorough at the source code level.
- The Frontend-to-Backend API Coverage audit and Runtime Dependency Map verification in the initial compliance report were performed with appropriate depth for source-level checks.

**Weaknesses:**

- No live integration smoke test was performed. This is an explicit mandatory requirement in `agent-roles.md` and was not met, despite being identified as a gap in R2 and committed to as a fix for R3.
- No staging environment correctness check was performed. The Vercel environment variable configuration was never read or compared against the expected staging values.
- The compliance re-check workflow did not contain a hard gate that required live URL access before the PASS could be written. The workflow allowed a complete and detailed artifact review to conclude with a PASS without the smoke test being performed.
- The R2 commitments existed as text in a self-review artifact but were not translated into actionable checklist items embedded in the re-check workflow. Commitments that are not embedded in the checklist are commitments that will be skipped under time pressure or habit.

---

## Commitments for R4

1. **Live integration smoke test is a hard gate — no PASS without it.** The Integration Smoke Test Results table must be the first section completed in any compliance re-check report, before the blocking issues re-check. The table requires: staging URL accessed, at least one content-backed page loaded, network log inspected to confirm API calls are reaching the staging API (not production), full auth flow completed (login, protected route access, logout). If the staging deployment is not accessible, the re-check must be suspended and the blockage escalated before a verdict is issued.

2. **Staging environment variable audit is a hard gate — no PASS without it.** Before issuing any PASS verdict for a deployment, I will run `vercel env ls` (or equivalent) against the deployed project and compare each variable value against the staging values in `agent_docs/project/deployment.md`. Any variable pointing to a production URL, a placeholder, or a non-existent endpoint will be raised as a blocking defect. This applies to `VITE_API_BASE_URL`, `VITE_API_URL`, any `CORS_ORIGINS` or `ALLOWED_ORIGINS` setting, and any variable with a production domain in its value.

3. **R2 commitments are embedded as checklist items, not prose.** The next compliance re-check template will include a mandatory pre-verdict checklist with binary pass/fail items. Each item from this and prior self-reviews will appear as a line in that checklist. The PASS verdict block will not be written until every checklist item is marked pass. Prose commitments in self-review artifacts have twice failed to change behaviour; a checklist embedded in the report structure is the mechanism that makes compliance enforceable.

4. **Deployment configuration defects that are not visible in source code are a known blind spot.** Any deployment where configuration lives outside the repository (Vercel env vars, Cloudflare worker secrets, Neon database connection strings, DNS configuration) requires explicit out-of-band verification. Source code correctness is necessary but not sufficient for a deployment PASS verdict.

5. **A commitment repeated across two self-reviews without execution is an escalation signal.** If any commitment from this self-review is not met in R4, that failure must be noted in the R4 self-review as a repeated failure and escalated to the retrospective-analyst for structural remediation — not treated as another item to re-commit to.

---

## PILOT STATUS
STATUS: COMPLETE
ARTIFACTS: artifacts/compliance/self-review-20260322-0000.md
