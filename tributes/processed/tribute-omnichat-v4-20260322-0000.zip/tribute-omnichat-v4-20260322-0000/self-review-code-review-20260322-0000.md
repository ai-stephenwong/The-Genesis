# Code Reviewer — Self-Review — 2026-03-22 00:00

## Trigger

Bug report: artifacts/development/bug-report-20260322-0000.md
Round: R3

---

## Observations

### OBS-01 — SEO fetch error not isolated — `Promise.all` made a non-critical dependency fatal

**What was found:**
`usePageContent.ts:33` called `Promise.all([getPageContent(), getPageSeo()])` with no error isolation on the SEO call. When the SEO endpoint (`GET /v1/public/seo/:pageId`) returned 404 — which it does for every page on an unseeded database — `Promise.all` rejected immediately, aborting the entire hook and rendering every page as "Unable to load content." The page content fetch succeeded, but the page was treated as completely broken. The fix was a single `.catch(() => null)` on the SEO call.

**What this agent did:**
The R3 code review (`artifacts/code-review/review-20260321-0000.md`) did not mention `usePageContent.ts` at all. The finding CR-016 flagged the wrong env var name (`VITE_API_URL` vs `VITE_API_BASE_URL`) in `services/api.ts`, demonstrating that the public web frontend was read. Despite reading the frontend services layer, the hook that calls those services was not reviewed with sufficient depth to catch the `Promise.all` error propagation pattern.

**Why it slipped through:**
Two compounding failures:

1. **Scope bias toward the API and CMS.** The review produced 28 findings across the API and CMS frontend. The public web frontend received only two mentions (CR-016 env var mismatch, CR-024 unused package). The `hooks/` directory — where `usePageContent.ts` lives — was not reviewed at all. The review implicitly treated the public web as lower risk because it has no auth, no write operations, and no complex business logic. This was wrong: data-fetching hooks are the critical rendering path for every page.

2. **No explicit check for error isolation in concurrent fetches.** The responsibilities defined in `agent-roles.md` include "Review logic correctness and edge cases." A `Promise.all` with no `.catch` on individual promises is a well-known edge case: any single failure poisons the entire result. There was no systematic check applied to data-fetching hooks to verify that non-critical concurrent fetches were isolated from critical ones. The question "what happens if this specific fetch returns 404?" was not asked for the SEO call.

The combination — undercoverage of the `hooks/` directory and no error-isolation checklist item — meant the bug was never reached.

---

### OBS-02 — Zero `t()` usage across ~20 components not flagged despite i18n being a documented requirement

**What was found:**
The i18n infrastructure was fully built: `react-i18next` configured, `HttpBackend` loading from `/public/locales/{lang}/translation.json`, translation files present for all 7 locales with correct translations. However, `useTranslation()` / `t()` was used in only 1 out of approximately 20 widgets and zero page components. All UI text — navigation labels, button text, body copy, error states, loading states — was hardcoded English. On language switch, only CMS-driven content fields (via `getField`) changed; all structural UI text stayed in English. The fix requires replacing hardcoded strings in every component with `t('key')` calls.

**What this agent did:**
The R3 code review (`artifacts/code-review/review-20260321-0000.md`) did not flag i18n integration at all. There is no finding — not Critical, not Major, not Minor, not Nit — that mentions `t()`, `useTranslation`, hardcoded strings, or translation coverage. The review identified 28 other findings but produced zero signal on this issue.

**Why it slipped through:**
Two root causes:

1. **No systematic coverage check for cross-cutting requirements.** i18n is a documented requirement for a multi-market, multi-locale product. The review examined individual files for correctness issues (wrong field names, missing endpoints, security vulnerabilities) but did not apply a requirement-driven pass: "for each documented non-functional requirement, is there evidence of implementation throughout the codebase?" A single scan across all `.tsx` files for the pattern `useTranslation` or `t(` would have immediately revealed that adoption was effectively zero outside one file. This scan was not performed.

2. **Infrastructure presence was not distinguished from integration completeness.** The i18n setup files (`i18n.ts`, translation JSON files, `HttpBackend` config) do constitute code and are individually correct. Had those files been reviewed in isolation, they would have appeared compliant. The failure was in not cross-referencing that setup against the consuming components to verify end-to-end integration. A correctly configured i18n system with zero adoption in components is equivalent to no i18n at all from the user's perspective — but this distinction requires a holistic view, not a file-by-file correctness check.

---

## Root Causes

| # | Root Cause | Affected Observations |
|---|---|---|
| RC-01 | Public web `hooks/` directory not reviewed — scope bias toward API and CMS left the primary rendering path of the public frontend unchecked | OBS-01 |
| RC-02 | No systematic error-isolation check applied to concurrent data fetches — `Promise.all` with unguarded promises is a known failure pattern that was not explicitly looked for | OBS-01 |
| RC-03 | No requirement-driven cross-cutting check — the review was conducted file-by-file for correctness rather than requirement-by-requirement for coverage; documented requirements (i18n) were not verified against component-level adoption | OBS-02 |
| RC-04 | Infrastructure presence conflated with integration completeness — correctly configured setup files were not cross-referenced against consuming components to verify end-to-end adoption | OBS-02 |

---

## Suggested Improvements (for agent-roles.md / next project)

### SUG-01 — Mandate explicit `hooks/` and `services/` coverage for public frontend projects

Add to the `code-reviewer` responsibilities: "For public-facing frontend projects, the `hooks/` and `services/` directories must be reviewed explicitly. For every custom hook that performs multiple concurrent fetches, verify that failures of non-critical fetches are isolated (e.g. `.catch(() => null)` or `Promise.allSettled`) so a single non-critical 404 cannot abort the entire page render."

This makes error-isolation in data-fetching hooks an explicit checklist item rather than something caught only if the reviewer happens to open the right file.

### SUG-02 — Add a cross-cutting requirements coverage pass to the review checklist

Add to the `code-reviewer` responsibilities: "Before closing the review, perform a requirement-driven pass: for each functional or non-functional requirement documented in `agent_docs/project/specs/requirements.md` or `architecture.md` (e.g. i18n, RBAC enforcement, audit logging, accessibility), search the codebase for evidence of end-to-end adoption. Flag any requirement where the infrastructure exists but component-level integration is absent or below a reasonable threshold as a Major finding."

For i18n specifically, this means: if `react-i18next` is configured, grep all `.tsx` files for `useTranslation` and report the adoption rate. A rate below 80% with hardcoded strings visible in components is a Major finding.

### SUG-03 — Distinguish infrastructure presence from integration completeness in the review output

Add a dedicated section to the code review output format: "Cross-Cutting Integration Checks." Each entry should record: (1) the requirement, (2) the infrastructure evidence (config files, packages), (3) the integration evidence (usage in consuming components), and (4) a verdict. This forces the reviewer to explicitly confirm that setup translates to adoption, not just that setup files are correct in isolation.

---

## Summary

This agent missed two Major bugs in R3.

For BUG-03-002, the `hooks/` directory of the public web frontend was not reviewed. The API and CMS received thorough coverage, but the public frontend's rendering path — the layer most visible to end users — was only partially read. Within what was read, there was no explicit check for error isolation in concurrent fetches, which is a standard failure mode of `Promise.all`.

For BUG-03-004, the review had no mechanism for requirement-driven coverage checks. i18n is a first-class documented requirement for a multi-locale product. The review process — which examined files for local correctness — never asked the question "is i18n actually used across the codebase?" A single grep would have answered it. The absence of any finding on this topic is a complete miss, not a borderline judgment call.

Both misses share a structural cause: the review was conducted as a file-by-file correctness audit rather than a combination of correctness audit and requirement-coverage verification. The suggested improvements above address this gap by making error-isolation checks and requirement-coverage passes explicit obligations in the `code-reviewer` role definition.

---

## Sign-off: code-reviewer — 2026-03-22 00:00
