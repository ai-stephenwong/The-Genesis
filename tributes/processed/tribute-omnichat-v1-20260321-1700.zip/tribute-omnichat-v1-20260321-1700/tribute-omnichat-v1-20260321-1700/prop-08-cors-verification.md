# PROP-08 — Post-Deploy CORS Verification in Deployment Runbook

## Target files
- `agent_docs/generic/deployment-vercel-cloudflare.md` — new "Post-Deploy Verification" section
- `agent_docs/generic/agent-roles.md` — `devops-engineer` — Pre-deploy checklist

## Problem being solved

`CORS_ALLOWED_ORIGINS` in `wrangler.toml` listed only custom domain URLs
(`uat.omnichat.ai`). The actual deployed frontend URLs were Vercel preview URLs
(`omnichat-v1-web.vercel.app`). All API calls from the frontend were blocked with
CORS errors. This was preventable by cross-checking the CORS list against the
documented frontend URLs in `deployment.md` before deploying the Worker.

## Proposed addition to deployment-vercel-cloudflare.md

Add a new section after "Cloudflare Workers First-Deployment Checklist":

```markdown
## Post-Deploy CORS Verification (mandatory before marking deploy complete)

After `wrangler deploy` completes:

1. Cross-check `CORS_ALLOWED_ORIGINS` against all frontend URLs in
   `agent_docs/project/deployment.md`:
   - [ ] All Vercel preview URLs are included (e.g. `https://omnichat-v1-web.vercel.app`)
   - [ ] All Vercel production URLs are included (e.g. `https://omnichat.ai`)
   - [ ] All custom domain URLs are included if configured

2. Run a CORS preflight test from each deployed frontend origin:
   ```bash
   curl -i -X OPTIONS <worker-url>/v1/auth/login \
     -H "Origin: <frontend-url>" \
     -H "Access-Control-Request-Method: POST" \
     -H "Access-Control-Request-Headers: Content-Type, Authorization"
   # Expected: HTTP/2 204, Access-Control-Allow-Origin: <frontend-url>
   ```
   If the response is missing `Access-Control-Allow-Origin` or returns 403/405,
   add the frontend URL to `CORS_ALLOWED_ORIGINS` and redeploy before proceeding.

3. For Vercel preview deployments with non-deterministic URLs:
   - Non-production environments only: add `https://*.vercel.app` to allowed origins
   - Production: never use a wildcard — only explicit domains

**Note:** Non-deterministic Vercel preview URLs (e.g. `project-abc123.vercel.app`)
cannot be enumerated in advance. The standard approach is to use the project's
stable Vercel URL (e.g. `omnichat-v1-web.vercel.app`) for all non-production
environments and set this as the CORS origin.
```

## Proposed addition to agent-roles.md — devops-engineer Pre-deploy checklist

Add to the existing Cloudflare Workers pre-deploy checklist:

```markdown
- [ ] `CORS_ALLOWED_ORIGINS` cross-checked against all frontend URLs in
      `agent_docs/project/deployment.md` — every documented frontend URL
      must appear in the Worker's allowed origins list
- [ ] CORS preflight test run from each deployed frontend origin:
      `curl -i -X OPTIONS <url>/v1/auth/login -H "Origin: <frontend>" ...`
      and verified to return correct `Access-Control-Allow-Origin` header
```
