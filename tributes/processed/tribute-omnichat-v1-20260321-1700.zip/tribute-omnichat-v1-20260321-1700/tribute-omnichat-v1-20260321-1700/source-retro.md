# Retrospective — 2026-03-21 17:00

## Round: 3 (Staging Integration Round — post-deployment live-site issues)

## Trigger
  Bug report: Staging deployment failures discovered after first live deployment.
  Primary recurring issue raised by user: "the mismatch of endpoint (domain) between
  the frontend and backend happens every time" — frontend built with wrong or missing
  API base URL, resulting in all API calls hitting the wrong host.
  Implicated agents: devops-engineer, developer, tester, code-reviewer

---

## Per-Agent Scores

| Agent | Round | Score (1–5) | Key Finding |
|---|---|---|---|
| devops-engineer | 3 | 2 | Deployment runbook missing migration step; CORS_ALLOWED_ORIGINS excluded actual deployed frontend origins; no env var name cross-check between deployment docs and source code |
| developer | 3 | 2 | Silent API URL fallback masked misconfiguration; wrong seed slug; seed data covered only 1 of 36 pages; test mocks used wrong Drizzle chain patterns |
| tester | 3 | 2 | Vitest mocks for Drizzle `update().set().where().returning()` chain and content-block select chain were structurally incorrect — tests passed with incorrect assumptions |
| code-reviewer | 3 | 3 | Did not flag silent fallback URL in `client.ts` as a deployment risk; did not cross-check `VITE_API_BASE_URL` against deployment docs |

---

## Agent Performance Detail

### devops-engineer

#### Independent Observations

Three distinct failures in this round:

**Finding 1 — Wrong env var name documented / not verified against source**
`wrangler secret put` and `agent_docs/project/deployment.md` referenced env var
`VITE_API_URL`. Source code (`src/api/client.ts`) reads `VITE_API_BASE_URL`.
Because Vite bakes env vars at build time, the discrepancy caused the frontend
to silently fall through to the hardcoded fallback URL. No error was surfaced.
No deployment step cross-checked the Vercel env var name against the actual
`import.meta.env.VITE_*` references in the source.

**Finding 2 — CORS_ALLOWED_ORIGINS excluded actual deployed frontend origins**
`wrangler.toml` `CORS_ALLOWED_ORIGINS` for staging listed:
`https://uat.omnichat.ai,https://cms-uat.omnichat.ai`
But actual deployed frontends were on Vercel preview URLs:
`https://omnichat-v1-web.vercel.app`, `https://omnichat-v1-cms-web.vercel.app`
The deployment docs describe these URLs as the staging frontends. The CORS config
was not cross-checked against these documented URLs before the Worker was deployed.

**Finding 3 — No database migration step in deployment runbook**
`agent_docs/project/deployment.md` Pre-Deployment Checklist includes:
"Neon DB branch for staging exists and migrations run"
However, no migration had ever been applied to the Neon staging branch.
`drizzle-kit generate:pg` had never been run; the migrations directory was empty.
The runbook item existed as a checkbox but no CI/CD step enforced it, and no
verification step confirmed the schema was applied before the Worker was deployed.

Additional issue: drizzle-kit generated `"tags" text[] DEFAULT  NOT NULL` (missing
default value) for `text[].default([])` columns. This bug required manual patching
of the SQL before it could be applied. There is no automated check in the pipeline
that validates generated migrations parse and apply cleanly on a fresh schema.

#### Root Cause Attribution: Agent Failure + Framework Gap

The CORS misconfiguration is an agent failure — the worker origin list did not
match the documented frontend URLs that the devops-engineer was required to read.
The missing migration step is mixed: the runbook mentioned it but the devops
agent did not provide a CI/CD step to enforce it (agent failure), and the
framework has no requirement to verify migrations apply cleanly on a clean DB
before deployment (framework gap).
The env var name mismatch is primarily a framework gap — no pipeline step requires
cross-checking env var names between Vercel settings and source code references.

**Classification: Mixed — agent failure (CORS origin list, migration enforcement)
+ framework gap (env var name verification, migration dry-run in CI).**

#### Score: 2
**Rationale:** Three distinct deployment integration failures, all preventable
with cross-checks against information available at deployment time. CORS origins
were documented; env var name is readable from source; migration checklist item
existed but was not enforced. Score is 2 rather than 1 because each finding has
a genuine framework gap component.

#### Self-Review Quality
No self-review produced (meta-pipeline round — direct analysis from observed failures).

---

### developer

#### Independent Observations

Four findings:

**Finding 1 — Silent API URL fallback obscured misconfiguration**
`src/api/client.ts`:
```ts
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'https://api.omnichat.ai';
```
When `VITE_API_BASE_URL` is not set, the app silently uses the production URL
in all environments. This means a staging deploy with an unset env var calls the
production API — or a non-existent production domain — with no visible error at
build time or runtime (until user sees "content could not be loaded").
A missing required env var should be a build-time failure, not a silent fallback.

**Finding 2 — Wrong seed slug**
Seed script created `slug = 'home'`. Frontend homepage route calls
`usePageContent('homepage')`. The slug was known at development time from the
route implementation itself. The mismatch meant the homepage API call returned
404 after migrations were applied correctly.

**Finding 3 — Seed data covered only 1 of 36 pages**
Frontend renders 36 distinct page slugs. The seed script seeded only 1.
All other pages returned 404, producing a visible error banner on every
non-homepage route. Seed data completeness was not verified against the
frontend's complete route list before the seed was considered done.

**Finding 4 — Test mocks used incorrect Drizzle chain patterns**
`tests/pages.test.ts`: `update()` chain mocked as
`{ set: mockReturnThis(), where: mockResolvedValue([page]) }`.
Actual Drizzle chain: `.update().set().where().returning()` — `where()` must
return `this`, `returning()` must resolve. Mock's `where()` resolved a value that
was then called with `.returning()`, causing "`.returning` is not a function".

`tests/public.test.ts`: content blocks select chain mocked as
`{ from: mockReturnThis(), where: mockReturnThis(), limit: mockResolvedValue([]) }`.
Actual service code: `await db.select().from().where()` with no `.limit()`.
`where()` must resolve directly. The mock structure did not match the service's
actual Drizzle call pattern.

`tests/pages.test.ts` publish test: `db.select()` called 4 times (page, sections,
latestVersion, inArray subquery). Mock had 3 `mockReturnValueOnce` calls and no
fallback — 4th call returned `undefined`, causing
"Cannot read properties of undefined (reading 'from')".

#### Root Cause Attribution: Agent Failure + Framework Gap

The silent fallback is an agent failure — removing the fallback and requiring
the env var explicitly is a basic defensive coding practice. The wrong seed slug
and incomplete seed data are agent failures — both were verifiable against frontend
route definitions that existed at development time. The wrong test mock patterns
are an agent failure — the mocks did not reflect the actual Drizzle call shapes.

There is a framework gap: no requirement exists for the developer to verify
seed data covers all routes the frontend will request. And no requirement exists
to verify `import.meta.env.VITE_*` env var names against deployment docs.

**Classification: Primarily agent failure; minor framework gaps.**

#### Score: 2
**Rationale:** Four separate integration failures all discoverable with basic
verification against existing code and documentation. Score is 2 rather than 1
because minor framework gaps exist for seed coverage and env var name reconciliation.

#### Self-Review Quality
No self-review produced (meta-pipeline round — direct analysis from observed failures).

---

### tester

#### Independent Observations

The test suite for `pages.test.ts` and `public.test.ts` shipped with Drizzle mock
chains that did not match the services' actual call patterns. As a result:

- The `PagesService.publish` test passed `update` mocks that would have thrown
  at runtime — the mock was accepted because it was never called with its full chain.
- The `PublicService.getPage` content-block test used a `limit()` mock that the
  service never calls — meaning the test was testing a code path that does not exist.
- The `inArray` subquery in `PagesService.publish` exhausted all `mockReturnValueOnce`
  calls, meaning the 4th `db.select()` call was entirely unguarded.

The tester role responsibility includes writing tests that accurately model the code
under test. Using `where: mockReturnThis()` when the service actually awaits
`where()` and using `limit: mockResolvedValue()` when the service never calls
`limit()` indicates the mocks were written from memory or assumption, not from
reading the actual service implementation.

No cross-service smoke test was written verifying frontend → API → database
connectivity, which would have caught the API URL mismatch before deployment.

#### Root Cause Attribution: Agent Failure + Framework Gap

Mocks not reflecting actual call patterns is an agent failure — the tester is
required to verify tests accurately model the code. The absence of a cross-service
smoke test is both an agent failure (the role definition requires cross-service
smoke tests) and a framework gap (no test template exists for Vercel → Workers →
Neon round-trips).

**Classification: Mixed — agent failure (incorrect mock patterns, missing
cross-service smoke test) + framework gap (no smoke test template for
Vercel/Workers/Neon stack).**

#### Score: 2
**Rationale:** Incorrect mock patterns produced tests that passed while hiding
structural mismatches. The missing cross-service smoke test means the most
important integration failure (API URL mismatch) had no automated detection.

#### Self-Review Quality
No self-review produced (meta-pipeline round — direct analysis from observed failures).

---

### code-reviewer

#### Independent Observations

Two findings:

**Finding 1 — Silent fallback URL not flagged as a deployment risk**
`client.ts` line: `import.meta.env.VITE_API_BASE_URL || 'https://api.omnichat.ai'`
The code-reviewer role definition requires checking that "cross-service env vars
are documented in `agent_docs/project/deployment.md` (CORS origins, API base URLs)".
The reviewer should have: (1) identified `VITE_API_BASE_URL` as a required env var,
(2) checked that `deployment.md` documents it with the exact name `VITE_API_BASE_URL`,
(3) flagged the silent fallback as a risk (wrong API called in staging without warning).
None of these checks were performed.

**Finding 2 — CORS_ALLOWED_ORIGINS not verified against deployment docs**
The reviewer is required to "check cross-service env vars are documented in
deployment.md (CORS origins, API base URLs)". The staging CORS origin list did not
include the documented Vercel frontend URLs. A review of `wrangler.toml` against
`deployment.md` would have caught this.

These are moderate failures, not critical — the reviewer's scope is broad and these
are configuration-level issues rather than logic errors. But both fall within the
explicitly defined responsibility to cross-check env vars against deployment docs.

#### Root Cause Attribution: Agent Failure

Both findings are within the code-reviewer's explicitly defined responsibilities.

**Classification: Agent failure.**

#### Score: 3
**Rationale:** The reviewer's defined cross-service env var check was not applied
thoroughly enough to catch the API URL name mismatch or the CORS origin gap.
These are not subtle omissions — `VITE_API_BASE_URL` appears once in `client.ts`
and the CORS origins appear once in `wrangler.toml`. Score is 3 (not 2) because
the failures are configuration-level (not logic errors) and the reviewer's other
responsibilities were largely met in the previous round.

#### Self-Review Quality
No self-review produced (meta-pipeline round — direct analysis from observed failures).

---

## Framework Gaps Identified

| # | Gap description | Proposed addition to agent-roles.md |
|---|---|---|
| FG-09 | No pipeline step cross-checks Vite env var names between source code (`import.meta.env.VITE_*`) and deployment documentation — wrong name results in silent fallback with no build error | Add env var name reconciliation to devops-engineer pre-deploy checklist and developer Spec Compliance Checklist |
| FG-10 | No requirement to remove silent API URL fallbacks — `import.meta.env.VITE_API_BASE_URL \|\| 'fallback'` allows misconfigured deployments to call wrong hosts silently | Add to developer checklist: required env vars must throw/fail at build time; no silent fallback to a hardcoded URL |
| FG-11 | No pipeline step to verify CORS_ALLOWED_ORIGINS in deployed Worker config matches documented frontend URLs — mismatch blocks all cross-origin API calls silently | Add CORS origin cross-check to devops-engineer pre-deploy checklist and compliance-officer smoke test |
| FG-12 | No requirement to run database migrations as a CI/CD step with a dry-run / apply-clean verification before first deployment — migrations directory can be empty or contain invalid SQL | Add migration dry-run and apply-clean step to deployment pipeline and devops-engineer responsibilities |
| FG-13 | No requirement for seed data to cover the complete set of routes/slugs the frontend will request — partial seed data causes visible error banners on all unseeded pages | Add seed coverage verification to developer checklist: seed must cover all route slugs used in the frontend |
| FG-14 | No cross-service smoke test template for Vercel → Workers → Neon stack — the most important integration path (frontend API call → Worker → DB) has no automated post-deploy verification | Add a required post-deploy smoke test step that verifies at least one full frontend → API → DB round-trip per environment |
| FG-15 | No CI/CD step updates Vercel env vars after API deployment — the API URL is only known after `wrangler deploy` completes, but no automated step propagates it to the frontend build | Add a post-API-deploy step to CI/CD pipeline that sets VITE_API_BASE_URL in Vercel and triggers a frontend rebuild |

---

## SDLC Improvement Proposals

These are actionable changes to be propagated to The Genesis.

---

### PROP-06 — Two-Phase Deployment: API First, Then Frontend Rebuild with Verified URL

**Target:** `agent_docs/generic/agent-roles.md` — `devops-engineer` — Responsibilities
**Also target:** `agent_docs/generic/deployment-vercel-cloudflare.md` — CI/CD Pipeline section

**Background:**
The user correctly identified the root cause: "the mismatch of endpoint (domain)
between the frontend and backend happens every time. I know you may not know the
final endpoint domain before first deployment."

The fundamental problem is a sequencing gap. The frontend is built with a Vite
env var (`VITE_API_BASE_URL`) that is baked at build time. But the API URL is only
known *after* the API is deployed. If both are deployed in the same pipeline run,
the frontend build happens before the API URL is confirmed — or the URL was set
in a previous session and may be stale.

**Optimal solution (three complementary mechanisms):**

**Mechanism A — Two-phase deploy in CI/CD:**
The CI/CD pipeline must be structured in two phases:
1. Phase 1: Deploy API (`wrangler deploy`) → capture the deployed Worker URL
2. Phase 2: Set `VITE_API_BASE_URL` in Vercel (`vercel env rm` + `vercel env add`) →
   trigger frontend redeploy (`vercel deploy --force`)

This ensures the frontend is *always* built against the real deployed API URL,
regardless of which was deployed first.

**Mechanism B — Fail loudly at build time if env var is missing:**
Remove the silent fallback in `client.ts`:
```ts
// WRONG — silently falls back to wrong host:
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'https://api.omnichat.ai';

// CORRECT — fails at build time if env var not set:
const apiBaseUrl = import.meta.env.VITE_API_BASE_URL;
if (!apiBaseUrl) throw new Error('VITE_API_BASE_URL is required — set it in Vercel env vars before building');
export const API_BASE_URL = apiBaseUrl;
```

**Mechanism C — Post-deploy cross-service smoke test in CI:**
After both deploys complete, run a smoke test:
```bash
# Verify frontend can reach API
curl -f https://omnichat-v1-web.vercel.app/api-health-check 2>/dev/null || \
  curl -f $(vercel inspect --json | jq -r '.url')/en \
    -H "X-Test-API-Reach: 1" --max-time 10
```
Or more precisely: fetch the frontend's `GET /health` equivalent that confirms
API connectivity. If this fails, the deploy is rolled back.

**Proposed change to devops-engineer Responsibilities:**

> **Two-Phase Deployment for Vercel + Cloudflare Workers projects (mandatory):**
>
> Because Vite bakes env vars at build time and the API Worker URL is only known
> after `wrangler deploy` completes, the CI/CD pipeline MUST be structured as
> two sequential phases:
>
> Phase 1 — API deploy:
> - Run `wrangler deploy --env <environment>`
> - Capture the deployed Worker URL from the output
> - Update `VITE_API_BASE_URL` in Vercel: `vercel env rm VITE_API_BASE_URL --environment preview && echo "<worker-url>" | vercel env add VITE_API_BASE_URL preview`
>
> Phase 2 — Frontend rebuild (triggered after Phase 1 completes):
> - Run `vercel deploy --force --prod` (or equivalent) to trigger a fresh build with the updated env var
> - Verify the deployed frontend's bundled API URL matches the Worker URL
>
> This pattern prevents the "wrong API domain" failure that occurs when frontend
> and backend are deployed in an unsequenced pipeline or when env vars are set
> manually after an initial deploy.
>
> **Env var name cross-check (mandatory):**
> Before setting any Vercel env var, verify the name matches the exact
> `import.meta.env.VITE_*` reference in `src/api/client.ts` (or equivalent).
> Document the canonical env var name in `agent_docs/project/deployment.md`.

---

### PROP-07 — Add API URL Env Var Verification to Developer and Code-Reviewer Checklists

**Target:** `agent_docs/generic/agent-roles.md` — `developer` — Spec Compliance Checklist
**Also target:** `agent_docs/generic/agent-roles.md` — `code-reviewer` — Responsibilities

**Proposed change to developer Spec Compliance Checklist:**

```markdown
- [ ] All Vite env var names used in source (`import.meta.env.VITE_*`) are
      listed in `agent_docs/project/deployment.md` with the exact spelling —
      no env var used in source may be absent from the deployment manifest
- [ ] No silent fallback to a hardcoded URL for required env vars —
      if `VITE_API_BASE_URL` is not set, the build must fail with a clear error,
      not silently use a fallback that points to the wrong environment
- [ ] Seed data covers every route slug the frontend will request via the API —
      verify against the complete list of `usePageContent(slug)` / `getPage(slug)`
      calls in the frontend codebase
```

**Proposed addition to code-reviewer Responsibilities:**

> **Env var name cross-check:** For every `import.meta.env.VITE_*` reference in the
> frontend, verify: (1) the exact name appears in `agent_docs/project/deployment.md`,
> (2) the name matches any Vercel env var documented in the deployment manifest,
> (3) no silent fallback to a hardcoded URL exists for required env vars.
> Flag any mismatch or silent fallback as a Major finding.

---

### PROP-08 — Add Post-Deploy CORS Verification to Deployment Runbook

**Target:** `agent_docs/generic/deployment-vercel-cloudflare.md` — new "Post-Deploy
Verification" section
**Also target:** `agent_docs/generic/agent-roles.md` — `devops-engineer` — Pre-deploy checklist

**Proposed change:**

Add to the Cloudflare Workers deployment checklist in `deployment-vercel-cloudflare.md`:

```markdown
## Post-Deploy CORS Verification (mandatory before marking deploy complete)

After `wrangler deploy` completes:

- [ ] `CORS_ALLOWED_ORIGINS` includes all deployed frontend URLs (Vercel preview + production)
      — verify against `agent_docs/project/deployment.md` frontend URLs
- [ ] Run CORS preflight test from deployed frontend origin:
      curl -i -X OPTIONS <worker-url>/v1/auth/login \
        -H "Origin: <frontend-url>" \
        -H "Access-Control-Request-Method: POST"
      Expected: 204, Access-Control-Allow-Origin: <frontend-url>
- [ ] If Vercel preview URLs are generated per-deploy (non-deterministic), add wildcard
      `https://*.vercel.app` only in non-production environments — never in production
```

---

### PROP-09 — Add Database Migration CI/CD Step with Apply-Clean Verification

**Target:** `agent_docs/generic/agent-roles.md` — `devops-engineer` — Responsibilities

**Proposed change:**

Add to devops-engineer Responsibilities:

> **Database Migration Pipeline Step (mandatory for all SQL database projects):**
>
> The CI/CD pipeline must include a migration step that runs before the application
> deploys to any environment. This step must:
>
> 1. Run the ORM migration tool (`drizzle-kit migrate`, `prisma migrate deploy`,
>    `alembic upgrade head`, etc.) against the environment's database
> 2. Verify exit code 0 (non-zero = hard blocker, deploy does not proceed)
> 3. Verify schema is applied by running a table-existence check query
>
> Before first deployment to any environment, also run:
> 4. A dry-run or `--check` mode that validates generated SQL parses without error
> 5. Apply on a scratch/test database to verify no column constraints fail
>    (e.g. drizzle-kit `DEFAULT  NOT NULL` bug for `text[]` columns)
>
> The Pre-Deployment Checklist item "migrations run" must be enforced by the
> pipeline — not left as a manual checkbox.

---

### PROP-10 — Add Seed Coverage Verification to Developer Checklist

**Target:** `agent_docs/generic/agent-roles.md` — `developer` — Spec Compliance Checklist

**Proposed change:**

Add to the developer Spec Compliance Checklist:

```markdown
- [ ] Seed data (or equivalent fixture data) covers the complete set of entity
      identifiers (slugs, IDs, keys) that the frontend will request via API at
      first load — verify by extracting all `usePageContent(slug)` / equivalent
      API calls from the frontend route files and confirming each has a matching
      seed entry
- [ ] Seed data field values comply with DB column constraints (varchar lengths,
      enum values, NOT NULL requirements) — verify by running the seed against
      a clean schema before submitting
```

---

## Score History (all rounds on this project)

| Agent | Round 1 (code defects) | Round 2 (deployment blockers) | Round 3 (integration) | Trend |
|---|---|---|---|---|
| solution-architect | N/A | 2 | N/A (not implicated) | — |
| devops-engineer | 2 | 2 | 2 | Flat |
| developer | 1 | 2 | 2 | +1, Flat |
| code-reviewer | 2 | N/A | 3 | +1 |
| tester | N/A | N/A | 2 | New |

---

## Overall Process Health: 2

**Rationale:**

The user's key observation — "the mismatch of endpoint (domain) between the
frontend and backend happens every time" — reveals a structural pipeline gap,
not an agent-level mistake. The gap is this: **the Vercel + Cloudflare Workers
deployment model has a sequencing problem that is not addressed anywhere in the
current pipeline standards.** Vite bakes env vars at build time; the Worker URL
is only known after deploy. The pipeline does not enforce the two-phase deploy
pattern (API first → update env var → rebuild frontend). Until this is enforced
in CI/CD (PROP-06), it will recur on every project in this stack.

The other issues in this round (wrong slug, missing seed data, incorrect test
mocks, CORS misconfiguration, missing migrations) are agent-level failures that
are each individually preventable with existing role definitions. But they
occurred together in the same deployment, which suggests the overall verification
culture before deployment sign-off is not yet at the right level.

The five proposals in this round (PROP-06 through PROP-10) address the structural
sequencing gap and the most frequently recurring verification gaps. PROP-06 is
the most important — it adds the two-phase deploy pattern to the framework as a
mandatory CI/CD structure for Vercel + Workers projects, which is the only
reliable fix for the recurring API domain mismatch.

---

## Sign-off: retrospective-analyst — 2026-03-21 17:00
