# Tribute — omnichat-v1 → The Genesis
## Date: 2026-03-21
## Round: 3 (Staging Integration Round)
## Source retro: artifacts/retrospective/retrospective-20260321-1700.md

---

## Summary

This tribute proposes five SDLC improvements discovered during the first staging
deployment of omnichat-v1. The primary recurring issue — frontend/backend API
domain mismatch on every first deployment of a Vercel + Cloudflare Workers project
— is addressed by PROP-06 (two-phase deploy pattern). All other proposals address
supporting verification gaps that allowed this and related issues to reach staging.

---

## Proposals Included

| ID | Title | Target file | Target section |
|---|---|---|---|
| PROP-06 | Two-Phase Deployment: API First, Then Frontend Rebuild with Verified URL | agent-roles.md + deployment-vercel-cloudflare.md | devops-engineer Responsibilities + CI/CD section |
| PROP-07 | API URL Env Var Verification in Developer and Code-Reviewer Checklists | agent-roles.md | developer Spec Compliance Checklist + code-reviewer Responsibilities |
| PROP-08 | Post-Deploy CORS Verification in Deployment Runbook | deployment-vercel-cloudflare.md + agent-roles.md | New "Post-Deploy Verification" section |
| PROP-09 | Database Migration CI/CD Step with Apply-Clean Verification | agent-roles.md | devops-engineer Responsibilities |
| PROP-10 | Seed Coverage Verification in Developer Checklist | agent-roles.md | developer Spec Compliance Checklist |

---

## Framework Gaps Addressed

| FG | Description |
|---|---|
| FG-09 | No env var name cross-check between source code and deployment docs |
| FG-10 | No requirement to remove silent API URL fallbacks |
| FG-11 | No CORS origin cross-check against documented frontend URLs |
| FG-12 | No migration dry-run / apply-clean in CI pipeline |
| FG-13 | No seed data coverage requirement against frontend route list |
| FG-14 | No cross-service smoke test template for Vercel → Workers → Neon |
| FG-15 | No two-phase deploy pattern enforcing API-first, then frontend rebuild |

---

## Files in this tribute

- `cover-note.md` — this file
- `prop-06-two-phase-deploy.md` — full proposal text with exact wording for agent-roles.md and deployment-vercel-cloudflare.md
- `prop-07-env-var-verification.md` — full proposal text
- `prop-08-cors-verification.md` — full proposal text
- `prop-09-migration-pipeline.md` — full proposal text
- `prop-10-seed-coverage.md` — full proposal text
- `source-retro.md` — copy of full retrospective for traceability
