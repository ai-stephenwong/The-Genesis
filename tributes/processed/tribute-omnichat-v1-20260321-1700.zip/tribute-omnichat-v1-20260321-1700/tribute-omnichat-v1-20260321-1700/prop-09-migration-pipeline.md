# PROP-09 — Database Migration CI/CD Step with Apply-Clean Verification

## Target files
- `agent_docs/generic/agent-roles.md` — `devops-engineer` — Responsibilities

## Problem being solved

No database migrations had been applied to the Neon staging branch before the
Worker was deployed. The Pre-Deployment Checklist included "migrations run" as a
manual checkbox, but this was not enforced by the CI/CD pipeline. Additionally,
the ORM (drizzle-kit) generated syntactically invalid SQL for `text[].default([])`
columns (`DEFAULT  NOT NULL` instead of `DEFAULT '{}'`), which would have failed
on any clean schema application. There was no automated step to catch this.

## Proposed addition to agent-roles.md — devops-engineer Responsibilities

Add to devops-engineer Responsibilities:

---

**Database Migration Pipeline Step (mandatory for all SQL database projects):**

The CI/CD pipeline must include a migration apply step that runs **before** the
application deploys to each environment. This step is a hard prerequisite —
the application deploy job must declare a `needs: [migrate]` dependency.

**Required pipeline jobs:**

```yaml
migrate:
  name: Apply database migrations
  runs-on: ubuntu-latest
  steps:
    - name: Run migrations
      run: |
        # For drizzle-kit:
        ./node_modules/.bin/drizzle-kit migrate --config drizzle.config.ts
        # For prisma:
        # npx prisma migrate deploy
        # For alembic:
        # alembic upgrade head
      env:
        DATABASE_URL: ${{ secrets.STAGING_DATABASE_URL }}

    - name: Verify schema applied (table existence check)
      run: |
        node -e "
          const { Pool } = require('pg');
          const pool = new Pool({ connectionString: process.env.DATABASE_URL });
          pool.query(\"SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public'\")
            .then(r => { console.log('Tables:', r.rows[0].count); pool.end(); })
            .catch(e => { console.error(e); process.exit(1); });
        "
      env:
        DATABASE_URL: ${{ secrets.STAGING_DATABASE_URL }}

deploy-api:
  needs: [migrate]   # API only deploys after migrations succeed
  ...
```

**Pre-first-deployment migration validation (mandatory before first deploy):**

Before the CI/CD pipeline runs for the first time in any environment:

1. Generate migrations from current schema:
   `./node_modules/.bin/drizzle-kit generate:pg` (or framework equivalent)

2. Validate generated SQL parses cleanly:
   `node -e "require('fs').readFileSync('migrations/0000_*.sql','utf8')" && echo "SQL OK"`

3. Apply on a scratch database and verify no constraint errors:
   Create a throwaway Neon branch, apply the migration, check for errors:
   ```bash
   neonctl branches create --name migration-test --project-id <id>
   # Apply migration, check exit code
   neonctl branches delete migration-test --project-id <id>
   ```

4. Known ORM bugs: drizzle-kit may generate `DEFAULT  NOT NULL` (missing value)
   for `text[].default([])` columns. After generation, verify all array columns
   have `DEFAULT '{}'` not `DEFAULT  NOT NULL`. Manual patch required if found.

---
