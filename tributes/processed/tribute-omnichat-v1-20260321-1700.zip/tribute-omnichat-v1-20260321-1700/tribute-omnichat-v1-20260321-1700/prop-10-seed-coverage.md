# PROP-10 — Seed Coverage Verification in Developer Checklist

## Target files
- `agent_docs/generic/agent-roles.md` — `developer` — Spec Compliance Checklist

## Problem being solved

The frontend renders 36 distinct page slugs via API calls. The seed script seeded
only 1 page (homepage, and initially with the wrong slug `home` instead of `homepage`).
All other pages returned 404, producing a visible error banner on every non-homepage
route. The developer had access to both the seed script and the frontend route files —
a simple grep would have revealed the mismatch.

## Proposed addition to developer Spec Compliance Checklist

Add to the existing checklist:

```markdown
- [ ] Seed data (or equivalent fixture data) covers every entity identifier the
      frontend will request via the API at first load. Verification method:
      1. Extract all API-dependent identifiers from frontend routes:
         grep -r "usePageContent\|getPage\|getPost\|getProduct" src/ | \
           grep -o "'[a-z0-9_-]*'" | sort -u
      2. Confirm each extracted slug/ID has a matching seed entry
      3. Any slug in the frontend with no matching seed entry = blocker before deploy

- [ ] Seed data field values comply with all DB column constraints:
      - varchar lengths do not exceed the column definition (e.g. meta_title varchar(60))
      - enum values match exactly the enum definition in the schema
      - NOT NULL columns have non-null values
      - Verify by running the seed against a clean local DB or migration-test branch
        and checking exit code 0 with no constraint violation errors

- [ ] Seed slugs match exactly what the frontend requests — verify by cross-checking
      the slug values in the seed script against the arguments passed to
      `usePageContent()` / `getPage()` / equivalent in the frontend source:
      grep -r "usePageContent\|getPage" src/ | grep -o "'[^']*'"
      # Each result must have a matching slug in the seed script
```

## Notes on enforcement

The seed coverage check is a developer responsibility because:
- The developer wrote both the frontend routes (slug names) and the seed script
- Both are available at development time — no deployment is needed to cross-check
- The mismatch is detectable with a 30-second grep, not a full integration test

This does NOT replace a post-deploy smoke test — it is a pre-deploy verification
that catches the most common seed gap (missing slugs) before deployment.
