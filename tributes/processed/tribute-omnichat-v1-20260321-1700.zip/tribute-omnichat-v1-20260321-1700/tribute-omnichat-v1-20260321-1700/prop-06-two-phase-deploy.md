# PROP-06 — Two-Phase Deployment: API First, Then Frontend Rebuild with Verified URL

## Target files
- `agent_docs/generic/agent-roles.md` — `devops-engineer` — Responsibilities
- `agent_docs/generic/deployment-vercel-cloudflare.md` — CI/CD Pipeline section

## Problem being solved

On Vercel + Cloudflare Workers projects, the frontend API base URL (`VITE_API_BASE_URL`)
is baked into the JavaScript bundle at Vite build time. The actual Worker URL is only
known *after* `wrangler deploy` completes. This creates a sequencing problem:

- If the frontend is deployed before the API, `VITE_API_BASE_URL` cannot be set yet.
- If both are deployed in the same pipeline run without a rebuild step, the frontend
  builds with a stale or missing env var.
- If the env var has a silent fallback (`|| 'https://api.omnichat.ai'`), the app
  silently calls the wrong host with no error surfaced at build time.

This has been observed to recur on every first deployment of a Vercel + Workers
project. It will continue to recur unless the two-phase pattern is enforced in the
pipeline standard.

## Proposed addition to agent-roles.md — devops-engineer Responsibilities

Add after the existing "Environments Configured" responsibility:

---

**Two-Phase Deployment for Vercel + Cloudflare Workers projects (mandatory):**

Because Vite bakes env vars at build time and the API Worker URL is only known
after `wrangler deploy` completes, the CI/CD pipeline MUST be structured in two
sequential phases for every Vercel + Cloudflare Workers project:

**Phase 1 — API deploy:**
```yaml
- name: Deploy API Worker
  run: wrangler deploy --env ${{ env.ENVIRONMENT }}
  id: deploy-api

- name: Capture Worker URL
  run: |
    WORKER_URL=$(wrangler deployments list --name omnichat-api-${{ env.ENV_NAME }} \
      --json | jq -r '.[0].url')
    echo "WORKER_URL=$WORKER_URL" >> $GITHUB_ENV

- name: Update frontend env var with deployed Worker URL
  run: |
    vercel env rm VITE_API_BASE_URL ${{ env.VERCEL_ENV }} --yes 2>/dev/null || true
    echo "$WORKER_URL" | vercel env add VITE_API_BASE_URL ${{ env.VERCEL_ENV }} \
      --token ${{ secrets.VERCEL_TOKEN }}
```

**Phase 2 — Frontend rebuild (triggered after Phase 1 completes):**
```yaml
- name: Rebuild and redeploy frontend with updated API URL
  run: vercel deploy --force --prod --token ${{ secrets.VERCEL_TOKEN }}

- name: Verify bundled API URL matches Worker URL
  run: |
    BUNDLE_URL=$(curl -s <frontend-url> | grep -o 'VITE_API_BASE_URL[^"]*' | head -1)
    [ "$BUNDLE_URL" = "$WORKER_URL" ] || (echo "API URL mismatch in bundle" && exit 1)
```

**Env var name cross-check (mandatory before any deploy):**
Before setting any Vercel env var, verify the name matches the exact
`import.meta.env.VITE_*` reference in `src/api/client.ts` (or equivalent):
```bash
grep -r "import.meta.env.VITE_" src/ | grep -v ".test." | sort -u
# Output must match what is set in Vercel — any discrepancy is a blocker
```
Document the canonical env var name in `agent_docs/project/deployment.md`.

**Silent fallback prohibition:**
The frontend must not have a silent fallback URL for required env vars:
```ts
// PROHIBITED — silently calls wrong host if env var is missing:
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'https://api.omnichat.ai';

// REQUIRED — fails at build time if env var is not set:
const apiBaseUrl = import.meta.env.VITE_API_BASE_URL;
if (!apiBaseUrl) throw new Error('VITE_API_BASE_URL is required — set it in Vercel env vars before building');
export const API_BASE_URL = apiBaseUrl;
```
Enforce this in code review. The devops-engineer must verify this pattern is used
before the first deployment.

---

## Proposed addition to deployment-vercel-cloudflare.md — CI/CD section

Add a new section "Two-Phase Deploy Pattern (Vercel + Workers)":

```markdown
## Two-Phase Deploy Pattern (Vercel + Cloudflare Workers)

Vite bakes `VITE_*` env vars at build time. The Worker URL is only known after
`wrangler deploy` completes. These two facts require a mandatory two-phase pipeline:

```
Phase 1: wrangler deploy → capture Worker URL → update Vercel VITE_API_BASE_URL
                 ↓
Phase 2: vercel deploy --force → verify bundled URL matches Worker URL
```

**Single-phase deploys (both in same job, no rebuild) are forbidden** for
Vercel + Workers projects because they produce a frontend bundle that may contain
a stale or missing API URL with no build-time error.

**Env var names must be verified against source before setting:**
Run `grep -r "import.meta.env.VITE_" src/` to extract exact names from source.
Set only those names — never a variation (e.g. `VITE_API_URL` ≠ `VITE_API_BASE_URL`).

**First deployment shortcut (manual):**
When setting up the pipeline for the first time, the URL is not yet known.
Acceptable approach:
1. Deploy API first: `wrangler deploy --env staging` → note the Worker URL
2. Set env var: `echo "<url>" | vercel env add VITE_API_BASE_URL preview`
3. Deploy frontend: `vercel deploy --force`
4. Add the two-phase automation to CI/CD before second deployment
```
