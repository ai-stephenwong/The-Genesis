# PROP-07 — API URL Env Var Verification in Developer and Code-Reviewer Checklists

## Target files
- `agent_docs/generic/agent-roles.md` — `developer` — Spec Compliance Checklist
- `agent_docs/generic/agent-roles.md` — `code-reviewer` — Responsibilities

## Problem being solved

The env var name used in source code (`VITE_API_BASE_URL`) differed from the name
documented in deployment docs and set in Vercel (`VITE_API_URL`). Neither the developer
nor the code-reviewer caught this because no checklist step requires cross-checking
these names. The developer sets the name in source; the devops-engineer sets it in
Vercel; they can silently disagree.

## Proposed addition to developer Spec Compliance Checklist

Add to the existing checklist in the `developer` output format:

```markdown
- [ ] All Vite env var names used in source (`import.meta.env.VITE_*`) are listed
      in `agent_docs/project/deployment.md` with the exact spelling — run:
      `grep -r "import.meta.env.VITE_" src/ | grep -v ".test."` and verify each
      name appears in the deployment manifest
- [ ] No silent fallback to a hardcoded URL for required env vars — if
      `VITE_API_BASE_URL` (or equivalent) is not set, the build must throw an error,
      not silently use a fallback URL that may point to the wrong environment or host
- [ ] Seed data covers every route slug / entity key the frontend will request via
      the API — verify by extracting all `usePageContent(slug)` / `getPage(slug)` /
      equivalent API calls from the frontend route files and confirming each has a
      matching seed entry in the seed script
```

## Proposed addition to code-reviewer Responsibilities

Add to the existing "Check cross-service env vars are documented" responsibility:

> **Env var name cross-check (extend existing responsibility):** For every
> `import.meta.env.VITE_*` reference in the frontend source, verify:
> (1) the exact name appears in `agent_docs/project/deployment.md` with identical
> spelling (case-sensitive),
> (2) no silent fallback to a hardcoded URL exists for required env vars —
> `import.meta.env.VAR || 'https://hardcoded.url'` is a **Major** finding when
> the var is required for correct operation.
> Flag any name mismatch between source and deployment docs as **Critical**.
